/**
 * Shared Embeds — Reusable EmbedBuilder factories for consistent styling.
 */

import { EmbedBuilder } from 'discord.js';
import { COLORS } from '../constants/index.js';

/**
 * Create a generic embed with a consistent style.
 */
export function createEmbed({ title, description, color = COLORS.PRIMARY, footer, fields = [] } = {}) {
  const embed = new EmbedBuilder()
    .setColor(color)
    .setTimestamp();

  if (title) embed.setTitle(title);
  if (description) embed.setDescription(description);
  if (footer) embed.setFooter({ text: footer });
  if (fields.length > 0) embed.addFields(fields);

  return embed;
}

/** Success embed (green). */
export function successEmbed(description, title = 'Success') {
  return createEmbed({ title, description, color: COLORS.SUCCESS });
}

/** Error embed (red). */
export function errorEmbed(description, title = 'Error') {
  return createEmbed({ title, description, color: COLORS.ERROR });
}

/** Warning embed (yellow). */
export function warningEmbed(description, title = 'Warning') {
  return createEmbed({ title, description, color: COLORS.WARNING });
}

/** Info embed (blue). */
export function infoEmbed(description, title = 'Info') {
  return createEmbed({ title, description, color: COLORS.INFO });
}
