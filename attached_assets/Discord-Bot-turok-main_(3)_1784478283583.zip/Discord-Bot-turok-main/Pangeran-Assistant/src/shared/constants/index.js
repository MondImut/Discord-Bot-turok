/**
 * Shared Constants — Application-wide constants and enumerations.
 */

/** Discord embed color palette */
export const COLORS = {
  PRIMARY: 0x5865F2,   // Blurple
  SUCCESS: 0x57F287,   // Green
  WARNING: 0xFEE75C,   // Yellow
  ERROR: 0xED4245,     // Red
  INFO: 0x3498DB,      // Blue
  DEFAULT: 0x2F3136,   // Dark
  TRANSPARENT: 0x2B2D31,
};

/** Millisecond duration helpers */
export const MS = {
  SECOND: 1_000,
  MINUTE: 60_000,
  HOUR: 3_600_000,
  DAY: 86_400_000,
};

/** Discord limits */
export const DISCORD = {
  EMBED_TITLE_MAX: 256,
  EMBED_DESCRIPTION_MAX: 4096,
  EMBED_FIELD_NAME_MAX: 256,
  EMBED_FIELD_VALUE_MAX: 1024,
  EMBED_FIELDS_MAX: 25,
  EMBED_FOOTER_MAX: 2048,
  EMBED_TOTAL_MAX: 6000,
  MESSAGE_MAX: 2000,
  OPTION_CHOICES_MAX: 25,
};

/** Default cooldown duration in seconds for interactions */
export const DEFAULT_COOLDOWN = 3;
