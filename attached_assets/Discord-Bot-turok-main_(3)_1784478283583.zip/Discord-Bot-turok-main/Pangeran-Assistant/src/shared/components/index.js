/**
 * Shared Components — Reusable discord.js UI component builders.
 */

import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
} from 'discord.js';

/**
 * Create a single-row action row containing buttons.
 * @param {ButtonBuilder[]} buttons
 * @returns {ActionRowBuilder}
 */
export function buttonRow(...buttons) {
  return new ActionRowBuilder().addComponents(...buttons);
}

/**
 * Create a primary (blurple) button.
 */
export function primaryButton(customId, label, options = {}) {
  return new ButtonBuilder()
    .setCustomId(customId)
    .setLabel(label)
    .setStyle(ButtonStyle.Primary)
    .setDisabled(options.disabled ?? false);
}

/**
 * Create a secondary (grey) button.
 */
export function secondaryButton(customId, label, options = {}) {
  return new ButtonBuilder()
    .setCustomId(customId)
    .setLabel(label)
    .setStyle(ButtonStyle.Secondary)
    .setDisabled(options.disabled ?? false);
}

/**
 * Create a danger (red) button.
 */
export function dangerButton(customId, label, options = {}) {
  return new ButtonBuilder()
    .setCustomId(customId)
    .setLabel(label)
    .setStyle(ButtonStyle.Danger)
    .setDisabled(options.disabled ?? false);
}

/**
 * Create a link button (opens a URL — has no customId).
 */
export function linkButton(url, label) {
  return new ButtonBuilder()
    .setURL(url)
    .setLabel(label)
    .setStyle(ButtonStyle.Link);
}

/**
 * Create a string select menu in an action row.
 * @param {string} customId
 * @param {Array<{label:string, value:string, description?:string}>} options
 * @param {object} [opts]
 */
export function selectMenu(customId, options, opts = {}) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId(customId)
    .setPlaceholder(opts.placeholder ?? 'Select an option…')
    .setMinValues(opts.minValues ?? 1)
    .setMaxValues(opts.maxValues ?? 1)
    .addOptions(options);

  return new ActionRowBuilder().addComponents(menu);
}
