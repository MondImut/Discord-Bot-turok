/**
 * Shared Helpers — General-purpose utility functions used across the bot.
 */

import os from 'os';

/**
 * Detect the hosting environment based on available environment variables and platform.
 * @returns {string}
 */
export function detectEnvironment() {
  if (process.env.REPL_ID || process.env.REPL_SLUG) return 'Replit';
  if (process.env.RAILWAY_ENVIRONMENT || process.env.RAILWAY_PROJECT_ID) return 'Railway';
  if (process.env.P_SERVER_UUID || process.env.PTERODACTYL_ALLOWED_IPS) return 'Pterodactyl';
  if (process.env.RENDER) return 'Render';
  if (process.env.HEROKU_APP_ID) return 'Heroku';

  const platform = os.platform();
  if (platform === 'win32') return 'Windows';
  if (platform === 'linux') return 'VPS Linux';
  if (platform === 'darwin') return 'macOS';
  return `Unknown (${platform})`;
}

/**
 * Format milliseconds into a human-readable duration string.
 * @param {number} ms
 * @returns {string} e.g. "2d 5h 30m 10s"
 */
export function formatDuration(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);

  const parts = [];
  if (d > 0) parts.push(`${d}d`);
  if (h % 24 > 0) parts.push(`${h % 24}h`);
  if (m % 60 > 0) parts.push(`${m % 60}m`);
  parts.push(`${s % 60}s`);
  return parts.join(' ');
}

/**
 * Truncate a string to a maximum length, appending an ellipsis if needed.
 */
export function truncate(str, maxLength = 100) {
  if (str.length <= maxLength) return str;
  return str.slice(0, maxLength - 1) + '…';
}

/**
 * Sleep for a given number of milliseconds.
 */
export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Chunk an array into smaller arrays of a given size.
 */
export function chunk(array, size) {
  const chunks = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

/**
 * Return the current memory usage in a readable format.
 */
export function memoryUsage() {
  const mem = process.memoryUsage();
  const toMB = (bytes) => (bytes / 1024 / 1024).toFixed(2);
  return {
    heapUsed: `${toMB(mem.heapUsed)} MB`,
    heapTotal: `${toMB(mem.heapTotal)} MB`,
    rss: `${toMB(mem.rss)} MB`,
  };
}

/**
 * Safely parse JSON. Returns undefined on failure.
 */
export function safeJsonParse(str) {
  try { return JSON.parse(str); } catch { return undefined; }
}
