/**
 * Shared Types — JSDoc type definitions for the framework.
 *
 * No runtime code — purely documentation for IDE support.
 *
 * @module types
 */

/**
 * @typedef {object} PluginMeta
 * @property {string} name - Unique plugin name (kebab-case recommended)
 * @property {string} version - Semantic version string (e.g. '1.0.0')
 * @property {string} [description] - Short description of the plugin's purpose
 */

/**
 * @typedef {object} DatabaseAdapter
 * @property {Function} connect - Establish the database connection
 * @property {Function} disconnect - Close the database connection
 * @property {Function} run - Execute a write statement
 * @property {Function} get - Fetch a single row
 * @property {Function} all - Fetch all matching rows
 * @property {Function} transaction - Execute inside a transaction
 * @property {Function} raw - Return the underlying driver instance
 * @property {Function} isConnected - Return whether the connection is active
 * @property {string} name - Adapter name (e.g. 'SQLite')
 */

/**
 * @typedef {object} CacheEntry
 * @property {*} value - The cached value
 * @property {number|null} expiresAt - Expiry timestamp in ms, or null for no expiration
 */

/**
 * @typedef {object} StartupInfo
 * @property {string} botName
 * @property {string} botVersion
 * @property {string} nodeVersion
 * @property {string} djsVersion
 * @property {string} environment
 * @property {string} os
 * @property {string} database
 * @property {number} pluginCount
 * @property {number} startupTimeMs
 */
