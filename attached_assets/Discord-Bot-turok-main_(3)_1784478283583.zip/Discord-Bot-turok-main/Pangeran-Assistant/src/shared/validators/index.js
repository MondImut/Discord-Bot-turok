/**
 * Shared Validators — Input validation helpers for commands and interactions.
 */

/**
 * Check if a string is a valid Discord Snowflake ID.
 */
export function isSnowflake(value) {
  return /^\d{17,20}$/.test(String(value));
}

/**
 * Check if a value is a non-empty string within an optional max length.
 */
export function isNonEmptyString(value, maxLength = Infinity) {
  return typeof value === 'string' && value.trim().length > 0 && value.length <= maxLength;
}

/**
 * Check if a number is within an inclusive range.
 */
export function isInRange(value, min, max) {
  return typeof value === 'number' && value >= min && value <= max;
}

/**
 * Check if a URL is valid.
 */
export function isValidUrl(value) {
  try {
    new URL(value);
    return true;
  } catch {
    return false;
  }
}

/**
 * Validate an interaction option exists and is a string.
 */
export function requireStringOption(interaction, name, required = true) {
  const value = interaction.options?.getString(name);
  if (required && !value) {
    throw new Error(`Missing required option: "${name}"`);
  }
  return value;
}
