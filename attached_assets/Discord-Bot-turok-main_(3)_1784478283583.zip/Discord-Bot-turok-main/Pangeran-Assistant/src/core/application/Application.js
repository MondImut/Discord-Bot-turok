/**
 * Application — Root orchestrator. Wires all core services together.
 *
 * This is the single object passed into plugins so they can access any
 * core service without creating circular dependencies.
 */

import os from 'os';
import { createRequire } from 'module';
import { Logger } from '../logger/Logger.js';
import { ConfigManager } from '../config/ConfigManager.js';
import { DatabaseManager } from '../database/DatabaseManager.js';
import { ClientManager } from '../client/ClientManager.js';
import { CacheManager } from '../cache/CacheManager.js';
import { Scheduler } from '../scheduler/Scheduler.js';
import { PermissionManager } from '../permissions/PermissionManager.js';
import { EventLoader } from '../loader/EventLoader.js';
import { PluginLoader } from '../loader/PluginLoader.js';
import { CommandRegistry } from '../registry/CommandRegistry.js';
import { detectEnvironment } from '../../shared/helpers/index.js';

// Use createRequire to access CommonJS package.json files
const require = createRequire(import.meta.url);

function getDjsVersion() {
  try {
    return require('discord.js/package.json').version;
  } catch {
    return '?';
  }
}

export class Application {
  // Public service references accessible by plugins
  logger;
  config;
  database;
  client;
  cache;
  scheduler;
  permissions;

  #pluginLoader;
  #commandRegistry;
  #startedAt;

  constructor() {
    // Logger is created first — everything else uses it
    this.logger = new Logger();
  }

  /**
   * Full startup sequence.
   */
  async start() {
    this.#startedAt = Date.now();

    // 1. Configuration
    this.config = new ConfigManager(this.logger);
    this.config.load();

    // Recreate logger with settings loaded from .env
    this.logger = new Logger({
      level: this.config.get('logger.level'),
      logToFile: this.config.get('logger.logToFile'),
      logDir: this.config.get('logger.logDir'),
    });

    // 2. Core services
    this.cache = new CacheManager(this.config.get('cache.ttl'));
    this.scheduler = new Scheduler(this.logger);
    this.permissions = new PermissionManager(this.logger);
    this.database = new DatabaseManager(this.logger);
    this.client = new ClientManager(this.logger);

    // 3. Database
    await this.database.connect(this.config.all().database);

    // 4. Events
    const eventLoader = new EventLoader(this.client, this.logger);
    await eventLoader.loadAll();

    // 5. Plugins
    this.#pluginLoader = new PluginLoader(this.logger);
    const pluginCount = await this.#pluginLoader.loadAll(this);

    // 6. Print startup banner
    this.#printStartupInfo(pluginCount);

    // 7. Register graceful shutdown handlers
    this.#registerShutdownHandlers();

    // 8. Command registry — runs once on 'ready', after all plugins have
    //    populated client.commands.  A single PUT replaces the full command
    //    list on Discord so stale/deleted commands are cleaned up automatically.
    this.#commandRegistry = new CommandRegistry(this.logger, this.config);
    this.client.client.once('ready', (discordClient) => {
      this.#commandRegistry.registerAll(discordClient).catch((err) => {
        this.logger.error(`CommandRegistry: ${err.message}`, 'App');
      });
    });

    // 9. Login to Discord
    await this.client.login(this.config.get('discord.token'));
  }

  #printStartupInfo(pluginCount) {
    const elapsed = Date.now() - this.#startedAt;
    const mem = process.memoryUsage();
    const memUsedMB = (mem.heapUsed / 1024 / 1024).toFixed(2);
    const totalMemMB = (os.totalmem() / 1024 / 1024).toFixed(0);
    const cpus = os.cpus();
    const cpuModel = cpus[0]?.model ?? 'Unknown';
    const env = detectEnvironment();
    const djsVersion = getDjsVersion();

    const row = (label, value) =>
      `  ${label.padEnd(22)} ${value}`;

    const lines = [
      '',
      '╔════════════════════════════════════════════════════╗',
      `║    ${this.config.get('bot.name').toUpperCase().padEnd(48)}║`,
      '╠════════════════════════════════════════════════════╣',
      row('Bot Name:', this.config.get('bot.name')),
      row('Bot Version:', `v${this.config.get('bot.version')}`),
      row('Node.js Version:', process.version),
      row('discord.js Version:', `v${djsVersion}`),
      row('Environment:', env),
      row('OS:', `${os.type()} ${os.release()} (${os.arch()})`),
      row('CPU:', `${cpuModel} × ${cpus.length}`),
      row('Memory:', `${memUsedMB} MB / ${totalMemMB} MB`),
      row('Database:', `${this.database.adapterName} (${this.database.isConnected() ? '✔ connected' : '✖ disconnected'})`),
      row('Plugins Loaded:', String(pluginCount)),
      row('Startup Time:', `${elapsed} ms`),
      '╚════════════════════════════════════════════════════╝',
      '',
    ];

    console.log(lines.join('\n'));
  }

  #registerShutdownHandlers() {
    const shutdown = async (signal) => {
      this.logger.warn(`Received ${signal}. Shutting down gracefully…`, 'App');
      try {
        this.scheduler.stopAll();
        await this.#pluginLoader.unloadAll();
        await this.database.disconnect();
        await this.client.destroy();
        this.logger.info('Shutdown complete. Goodbye. 👋', 'App');
        this.logger.close();
      } catch (err) {
        this.logger.error(`Error during shutdown: ${err.message}`, 'App');
      } finally {
        process.exit(0);
      }
    };

    process.once('SIGINT', () => shutdown('SIGINT'));
    process.once('SIGTERM', () => shutdown('SIGTERM'));

    process.on('uncaughtException', (err) => {
      this.logger.error(`Uncaught Exception: ${err.message}`, 'App');
      if (process.env.LOG_LEVEL === 'DEBUG') {
        this.logger.error(err.stack ?? '', 'App');
      }
    });

    process.on('unhandledRejection', (reason) => {
      this.logger.error(`Unhandled Rejection: ${String(reason)}`, 'App');
    });
  }
}
