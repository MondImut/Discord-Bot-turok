/**
 * Scheduler — Cron-based task scheduler using node-cron.
 */

import cron from 'node-cron';

export class Scheduler {
  #tasks = new Map();
  #logger;

  constructor(logger) {
    this.#logger = logger;
  }

  /**
   * Register a recurring task.
   * @param {string} name - Unique task identifier.
   * @param {string} schedule - Cron expression (e.g. '0 * * * *').
   * @param {Function} fn - Async or sync function to execute.
   */
  register(name, schedule, fn) {
    if (this.#tasks.has(name)) {
      this.#logger.warn(`Task "${name}" is already registered. Skipping.`, 'Scheduler');
      return;
    }

    if (!cron.validate(schedule)) {
      this.#logger.error(`Invalid cron expression for task "${name}": ${schedule}`, 'Scheduler');
      return;
    }

    const task = cron.schedule(schedule, async () => {
      try {
        await fn();
      } catch (err) {
        this.#logger.error(`Task "${name}" threw an error: ${err.message}`, 'Scheduler');
      }
    }, { scheduled: true });

    this.#tasks.set(name, task);
    this.#logger.info(`Task registered: "${name}" [${schedule}]`, 'Scheduler');
  }

  /** Stop and remove a scheduled task. */
  unregister(name) {
    const task = this.#tasks.get(name);
    if (!task) return false;

    task.stop();
    this.#tasks.delete(name);
    this.#logger.info(`Task unregistered: "${name}"`, 'Scheduler');
    return true;
  }

  /** Stop all tasks (called on shutdown). */
  stopAll() {
    for (const [name, task] of this.#tasks.entries()) {
      task.stop();
      this.#logger.debug(`Stopped task: "${name}"`, 'Scheduler');
    }
    this.#tasks.clear();
  }

  get taskCount() {
    return this.#tasks.size;
  }
}
