/**
 * CommandRegistry — Centralized auto-registration for all Discord Slash Commands.
 *
 * Responsibilities:
 *   - Scans client.commands (populated by plugins via commands.set())
 *   - Validates each command's structure
 *   - Registers all commands with Discord on ready (guild or global mode)
 *   - A full PUT replaces the entire command list — old/deleted commands are
 *     automatically removed (no stale commands remain)
 *   - Auto-registers in new guilds when the bot joins them (guild mode only)
 *   - Logs a detailed summary: found / registered / mode / timing
 *   - Never throws — registration failures are logged so the bot keeps running
 */

import { REST, Routes } from 'discord.js';

export class CommandRegistry {
  #logger;
  #config;

  constructor(logger, config) {
    this.#logger = logger;
    this.#config = config;
  }

  /**
   * Collect all commands from client.commands, validate them, and PUT them
   * to Discord.  Must be called inside the 'ready' event so all plugins have
   * already registered their commands.
   *
   * @param {import('discord.js').Client} discordClient
   */
  async registerAll(discordClient) {
    const startTime = Date.now();
    const token    = this.#config.get('discord.token');
    const clientId = this.#config.get('discord.clientId');
    const guildId  = this.#config.get('discord.guildId');

    // ── Credential check ────────────────────────────────────────────────────
    if (!token || !clientId) {
      this.#logger.error(
        'Cannot register commands: DISCORD_TOKEN or DISCORD_CLIENT_ID is missing.',
        'CommandRegistry',
      );
      return;
    }

    // ── Collect & validate ───────────────────────────────────────────────────
    const commandBodies     = [];
    const failedValidation  = [];

    for (const [name, command] of discordClient.commands) {
      if (!command.data) {
        failedValidation.push({ name, reason: 'Missing .data property' });
        continue;
      }

      // Support both SlashCommandBuilder instances and plain JSON objects
      const body = typeof command.data.toJSON === 'function'
        ? command.data.toJSON()
        : command.data;

      if (!body || !body.name) {
        failedValidation.push({ name, reason: 'Command .data has no .name field' });
        continue;
      }

      commandBodies.push(body);
    }

    const totalFound = commandBodies.length + failedValidation.length;

    if (failedValidation.length > 0) {
      for (const { name, reason } of failedValidation) {
        this.#logger.warn(`  ✖ "${name}" skipped — ${reason}`, 'CommandRegistry');
      }
    }

    if (commandBodies.length === 0) {
      this.#logger.warn('No valid commands to register.', 'CommandRegistry');
      return;
    }

    // ── Register ─────────────────────────────────────────────────────────────
    const rest = new REST().setToken(token);
    const mode = guildId ? 'Guild' : 'Global';

    try {
      if (guildId) {
        // Guild commands — instant propagation
        await rest.put(
          Routes.applicationGuildCommands(clientId, guildId),
          { body: commandBodies },
        );
      } else {
        // Global commands — up to 1 h propagation
        await rest.put(
          Routes.applicationCommands(clientId),
          { body: commandBodies },
        );
      }

      const elapsed = Date.now() - startTime;

      // ── Summary log ─────────────────────────────────────────────────────────
      this.#logger.success('─── Slash Command Registration ─────────────────────', 'CommandRegistry');
      this.#logger.success(`  ✓ Total commands found      : ${totalFound}`, 'CommandRegistry');
      this.#logger.success(`  ✓ Commands registered       : ${commandBodies.length}`, 'CommandRegistry');
      this.#logger.success(`  ✓ Mode                      : ${mode}${guildId ? ` (Guild: ${guildId})` : ''}`, 'CommandRegistry');
      this.#logger.success(`  ✓ Registration time         : ${elapsed} ms`, 'CommandRegistry');
      this.#logger.success('────────────────────────────────────────────────────', 'CommandRegistry');

      commandBodies.forEach((cmd) =>
        this.#logger.info(`  ↳ /${cmd.name} — ${cmd.description ?? '(no description)'}`, 'CommandRegistry'),
      );

    } catch (err) {
      this.#logger.error('─── Slash Command Registration FAILED ──────────────', 'CommandRegistry');
      this.#_handleRestError(err, guildId);
      this.#logger.error('────────────────────────────────────────────────────', 'CommandRegistry');
      // Do NOT rethrow — bot continues running even if registration fails
      return;
    }

    // ── Auto-register in new guilds ──────────────────────────────────────────
    if (guildId) {
      // Guild mode: only relevant for the configured guild
      discordClient.on('guildCreate', async (guild) => {
        if (guild.id !== guildId) return;
        try {
          await rest.put(
            Routes.applicationGuildCommands(clientId, guild.id),
            { body: commandBodies },
          );
          this.#logger.info(`Commands re-registered in guild: ${guild.name}`, 'CommandRegistry');
        } catch (err) {
          this.#logger.warn(`Failed to register commands in ${guild.name}: ${err.message}`, 'CommandRegistry');
        }
      });
    } else {
      // Global mode: commands are available in all guilds automatically
      discordClient.on('guildCreate', (guild) => {
        this.#logger.debug(`Global commands available in new guild: ${guild.name}`, 'CommandRegistry');
      });
    }
  }

  /**
   * Translate Discord REST errors into human-readable messages.
   * @param {Error} err
   * @param {string} guildId
   */
  #_handleRestError(err, guildId) {
    if (err.status === 401) {
      this.#logger.error(
        '  ✖ DISCORD_TOKEN is invalid or revoked.\n' +
        '    → Regenerate your bot token at https://discord.com/developers/applications',
        'CommandRegistry',
      );
    } else if (err.status === 403) {
      this.#logger.error(
        '  ✖ Bot lacks the "applications.commands" OAuth2 scope.\n' +
        '    → Re-invite the bot with the correct scopes:\n' +
        '      https://discord.com/developers/applications → OAuth2 → bot + applications.commands',
        'CommandRegistry',
      );
    } else if (err.code === 10004 || (err.message && err.message.includes('Unknown Guild'))) {
      this.#logger.error(
        `  ✖ Unknown guild "${guildId}" — DISCORD_GUILD_ID may be wrong.\n` +
        '    → Remove DISCORD_GUILD_ID to use Global Commands, or fix the Guild ID.',
        'CommandRegistry',
      );
    } else if (err.code === 50035) {
      this.#logger.error(
        `  ✖ Invalid command structure: ${err.message}`,
        'CommandRegistry',
      );
    } else {
      this.#logger.error(
        `  ✖ Unexpected error (${err.status ?? err.code ?? 'unknown'}): ${err.message}`,
        'CommandRegistry',
      );
    }
  }
}
