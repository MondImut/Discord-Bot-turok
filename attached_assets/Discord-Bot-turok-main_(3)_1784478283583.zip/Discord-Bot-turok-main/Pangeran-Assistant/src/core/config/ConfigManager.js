/**
 * ConfigManager — Loads and validates environment configuration using dotenv.
 */

import { config } from 'dotenv';
import path from 'path';
import fs from 'fs';

export class ConfigManager {
  #data = {};
  #logger;

  constructor(logger) {
    this.#logger = logger;
  }

  /**
   * Load .env from the project root and validate required fields.
   */
  load() {
    const envPath = path.resolve(process.cwd(), '.env');

    if (fs.existsSync(envPath)) {
      config({ path: envPath });
      this.#logger.info('Loaded .env file.', 'Config');
    } else {
      this.#logger.warn('.env file not found — using existing environment variables.', 'Config');
    }

    this.#data = this.#buildConfig();
    this.#validate();

    return this;
  }

  #buildConfig() {
    return {
      discord: {
        token: process.env.DISCORD_TOKEN || process.env.BOT_TOKEN || '',
        clientId: process.env.DISCORD_CLIENT_ID || process.env.CLIENT_ID || '',
        guildId: process.env.DISCORD_GUILD_ID || '',
      },
      bot: {
        name: process.env.BOT_NAME || 'Pangeran Assistant',
        version: process.env.BOT_VERSION || '1.0.0',
        prefix: process.env.BOT_PREFIX || '!',
      },
      database: {
        adapter: process.env.DB_ADAPTER || 'sqlite',
        path: process.env.DB_PATH || './data/database/pangeran.db',
      },
      logger: {
        level: process.env.LOG_LEVEL || 'INFO',
        logToFile: process.env.LOG_TO_FILE !== 'false',
        logDir: process.env.LOG_DIR || './logs',
      },
      cache: {
        ttl: parseInt(process.env.CACHE_TTL || '300', 10),
      },
      debug: {
        discord: process.env.DEBUG_DISCORD === 'true',
      },
    };
  }

  #validate() {
    const required = [
      { key: 'DISCORD_TOKEN', value: this.#data.discord.token, hint: 'Add DISCORD_TOKEN to your .env file.' },
      { key: 'DISCORD_CLIENT_ID', value: this.#data.discord.clientId, hint: 'Add DISCORD_CLIENT_ID to your .env file.' },
    ];

    const missing = required.filter(({ value }) => !value || value.startsWith('your_'));

    if (missing.length > 0) {
      const messages = missing.map(({ key, hint }) => `  ✖ ${key}: ${hint}`).join('\n');
      this.#logger.error(`Missing required configuration:\n${messages}`, 'Config');
      throw new Error('Configuration validation failed. See above for details.');
    }

    this.#logger.success('Configuration validated.', 'Config');
  }

  /** Access nested config values with dot notation, e.g. get('discord.token') */
  get(keyPath) {
    return keyPath.split('.').reduce((obj, key) => obj?.[key], this.#data);
  }

  /** Return the full config object (read-only copy). */
  all() {
    return structuredClone(this.#data);
  }
}
