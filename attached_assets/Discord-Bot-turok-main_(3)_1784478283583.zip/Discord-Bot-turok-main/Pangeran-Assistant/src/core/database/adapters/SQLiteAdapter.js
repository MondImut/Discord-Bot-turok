/**
 * SQLiteAdapter — Uses better-sqlite3 for synchronous SQLite access on Node.js 18–22.
 * Implements the standard DatabaseAdapter interface so it can be swapped for another adapter.
 */

import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const Database = require('better-sqlite3');
import path from 'path';
import fs from 'fs';

export class SQLiteAdapter {
  #db = null;
  #dbPath;
  #logger;

  constructor(dbPath, logger) {
    this.#dbPath = path.resolve(process.cwd(), dbPath);
    this.#logger = logger;
  }

  connect() {
    const dir = path.dirname(this.#dbPath);
    fs.mkdirSync(dir, { recursive: true });

    this.#db = new Database(this.#dbPath);

    // Enable WAL mode for better concurrent read performance
    this.#db.exec('PRAGMA journal_mode = WAL');
    this.#db.exec('PRAGMA foreign_keys = ON');

    this.#logger.success(`SQLite connected → ${this.#dbPath}`, 'Database');
  }

  disconnect() {
    if (this.#db) {
      this.#db.close();
      this.#db = null;
      this.#logger.info('SQLite connection closed.', 'Database');
    }
  }

  /** Execute a write statement (INSERT, UPDATE, DELETE, CREATE). */
  run(sql, params = []) {
    return this.#db.prepare(sql).run(...(Array.isArray(params) ? params : [params]));
  }

  /** Fetch a single row. */
  get(sql, params = []) {
    return this.#db.prepare(sql).get(...(Array.isArray(params) ? params : [params]));
  }

  /** Fetch all matching rows. */
  all(sql, params = []) {
    return this.#db.prepare(sql).all(...(Array.isArray(params) ? params : [params]));
  }

  /** Execute raw SQL (no params). */
  exec(sql) {
    return this.#db.exec(sql);
  }

  /** Execute a series of statements inside an implicit transaction. */
  transaction(fn) {
    this.#db.exec('BEGIN');
    try {
      const result = fn(this);
      this.#db.exec('COMMIT');
      return result;
    } catch (err) {
      this.#db.exec('ROLLBACK');
      throw err;
    }
  }

  /** Return the underlying DatabaseSync instance for advanced use. */
  raw() {
    return this.#db;
  }

  isConnected() {
    return this.#db !== null && this.#db.open;
  }

  get name() {
    return 'SQLite';
  }
}
