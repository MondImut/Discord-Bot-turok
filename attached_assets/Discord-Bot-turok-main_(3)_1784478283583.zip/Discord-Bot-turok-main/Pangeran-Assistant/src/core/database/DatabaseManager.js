/**
 * DatabaseManager — Adapter-based database manager.
 * Supports swapping database backends without touching Core or plugins.
 */

import { SQLiteAdapter } from './adapters/SQLiteAdapter.js';

const ADAPTERS = {
  sqlite: SQLiteAdapter,
};

export class DatabaseManager {
  #adapter = null;
  #logger;

  constructor(logger) {
    this.#logger = logger;
  }

  /**
   * Initialize the database with the configured adapter.
   * @param {object} config - database config ({ adapter, path, ... })
   */
  async connect(config = {}) {
    const adapterName = config.adapter || 'sqlite';
    const AdapterClass = ADAPTERS[adapterName];

    if (!AdapterClass) {
      throw new Error(
        `Unknown database adapter: "${adapterName}". Available: ${Object.keys(ADAPTERS).join(', ')}`
      );
    }

    this.#adapter = new AdapterClass(config.path || './data/database/pangeran.db', this.#logger);
    this.#adapter.connect();
  }

  async disconnect() {
    if (this.#adapter) {
      this.#adapter.disconnect();
    }
  }

  /** Register a custom adapter for use in plugins or extensions. */
  registerAdapter(name, AdapterClass) {
    ADAPTERS[name] = AdapterClass;
    this.#logger.info(`Database adapter registered: ${name}`, 'Database');
  }

  /** Execute a write statement. */
  run(sql, params) { return this.#adapter.run(sql, params); }

  /** Fetch a single row. */
  get(sql, params) { return this.#adapter.get(sql, params); }

  /** Fetch all matching rows. */
  all(sql, params) { return this.#adapter.all(sql, params); }

  /** Execute inside a transaction. */
  transaction(fn) { return this.#adapter.transaction(fn); }

  /** Access the raw adapter instance. */
  raw() { return this.#adapter.raw(); }

  isConnected() {
    return this.#adapter?.isConnected() ?? false;
  }

  get adapterName() {
    return this.#adapter?.name ?? 'none';
  }
}
