/**
 * PluginBase — Abstract base class for all Pangeran Assistant plugins.
 *
 * Every plugin must extend this class and implement the required methods.
 *
 * @example
 * import { PluginBase } from '../src/core/plugin/PluginBase.js';
 *
 * export default class PingPlugin extends PluginBase {
 *   static meta = { name: 'ping', version: '1.0.0', description: 'Simple ping command.' };
 *
 *   async onLoad(app) {
 *     app.logger.info('PingPlugin loaded!', 'PingPlugin');
 *   }
 *
 *   async onUnload() {}
 * }
 */

export class PluginBase {
  /**
   * Plugin metadata. Must be overridden by the subclass.
   * @type {{ name: string, version: string, description: string }}
   */
  static meta = { name: 'unnamed', version: '0.0.0', description: '' };

  /**
   * Called by PluginLoader after the plugin is instantiated.
   * Use this to register commands, event listeners, scheduled tasks, etc.
   * @param {import('../application/Application.js').Application} app
   */
  async onLoad(app) {
    throw new Error(`Plugin "${this.constructor.meta?.name ?? 'unnamed'}" must implement onLoad(app).`);
  }

  /**
   * Called by PluginLoader when the plugin is unloaded (e.g. on shutdown or hot-reload).
   * Clean up listeners, scheduled tasks, and other resources here.
   */
  async onUnload() {
    // Default no-op — override if the plugin needs cleanup.
  }

  /** Shorthand to access plugin name from an instance. */
  get name() {
    return this.constructor.meta?.name ?? 'unnamed';
  }
}
