/**
 * Logger — Professional multi-level logger with console and file output.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const LEVELS = {
  DEBUG: 0,
  INFO: 1,
  SUCCESS: 2,
  WARN: 3,
  ERROR: 4,
};

// ANSI color codes (no external dep needed for basic colors)
const COLORS = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  DEBUG: '\x1b[36m',    // cyan
  INFO: '\x1b[34m',     // blue
  SUCCESS: '\x1b[32m',  // green
  WARN: '\x1b[33m',     // yellow
  ERROR: '\x1b[31m',    // red
  timestamp: '\x1b[90m', // gray
  tag: '\x1b[35m',      // magenta
};

const ICONS = {
  DEBUG: '🔍',
  INFO: '📋',
  SUCCESS: '✅',
  WARN: '⚠️ ',
  ERROR: '❌',
};

export class Logger {
  #minLevel;
  #logToFile;
  #logDir;
  #logStream = null;

  constructor(options = {}) {
    this.#minLevel = LEVELS[options.level?.toUpperCase()] ?? LEVELS.INFO;
    this.#logToFile = options.logToFile ?? true;
    this.#logDir = options.logDir ?? './logs';

    if (this.#logToFile) {
      this.#initFileStream();
    }
  }

  #initFileStream() {
    try {
      const absDir = path.resolve(process.cwd(), this.#logDir);
      fs.mkdirSync(absDir, { recursive: true });

      const date = new Date().toISOString().slice(0, 10);
      const logFile = path.join(absDir, `${date}.log`);

      this.#logStream = fs.createWriteStream(logFile, { flags: 'a' });
    } catch (err) {
      console.error(`[Logger] Failed to initialize log file: ${err.message}`);
    }
  }

  #formatTimestamp() {
    return new Date().toISOString().replace('T', ' ').slice(0, 23);
  }

  #write(level, message, tag = '') {
    if (LEVELS[level] < this.#minLevel) return;

    const ts = this.#formatTimestamp();
    const icon = ICONS[level];
    const tagStr = tag ? `[${tag}] ` : '';

    // Console output with colors
    const coloredLine = [
      `${COLORS.timestamp}${ts}${COLORS.reset}`,
      `${COLORS[level]}${COLORS.bright}${icon} ${level.padEnd(7)}${COLORS.reset}`,
      tag ? `${COLORS.tag}[${tag}]${COLORS.reset}` : '',
      message,
    ].filter(Boolean).join(' ');

    console.log(coloredLine);

    // File output (plain text, no ANSI)
    if (this.#logStream) {
      const plainLine = `${ts} ${level.padEnd(7)} ${tagStr}${message}\n`;
      this.#logStream.write(plainLine);
    }
  }

  debug(message, tag) { this.#write('DEBUG', message, tag); }
  info(message, tag)  { this.#write('INFO', message, tag); }
  success(message, tag) { this.#write('SUCCESS', message, tag); }
  warn(message, tag)  { this.#write('WARN', message, tag); }
  error(message, tag) { this.#write('ERROR', message, tag); }

  /**
   * Log an error object with stack trace.
   */
  exception(err, tag = 'Error') {
    this.error(`${err.message}`, tag);
    if (LEVELS.DEBUG >= this.#minLevel && err.stack) {
      this.debug(err.stack, tag);
    }
  }

  close() {
    if (this.#logStream) {
      this.#logStream.end();
      this.#logStream = null;
    }
  }
}
