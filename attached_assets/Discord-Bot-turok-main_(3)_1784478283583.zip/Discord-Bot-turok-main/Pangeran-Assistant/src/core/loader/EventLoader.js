/**
 * EventLoader — Scans the events/ directory and registers listeners on the client.
 */

import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

export class EventLoader {
  #logger;
  #clientManager;
  #eventsDir;

  constructor(clientManager, logger) {
    this.#clientManager = clientManager;
    this.#logger = logger;
    this.#eventsDir = path.resolve(process.cwd(), 'src', 'events');
  }

  /**
   * Load and register all events from src/events/.
   * @returns {number} Number of events registered.
   */
  async loadAll() {
    if (!fs.existsSync(this.#eventsDir)) {
      this.#logger.warn('Events directory not found. Skipping.', 'EventLoader');
      return 0;
    }

    const files = fs
      .readdirSync(this.#eventsDir)
      .filter((f) => f.endsWith('.js'));

    let count = 0;

    for (const file of files) {
      try {
        const filePath = pathToFileURL(path.join(this.#eventsDir, file)).href;
        const module = await import(filePath);
        const event = module.default;

        if (!event?.name || typeof event.execute !== 'function') {
          this.#logger.warn(`Event file "${file}" is missing "name" or "execute". Skipping.`, 'EventLoader');
          continue;
        }

        if (event.once) {
          this.#clientManager.once(event.name, (...args) => event.execute(...args));
        } else {
          this.#clientManager.on(event.name, (...args) => event.execute(...args));
        }

        this.#logger.debug(`Registered event: ${event.name}`, 'EventLoader');
        count++;
      } catch (err) {
        this.#logger.error(`Failed to load event "${file}": ${err.message}`, 'EventLoader');
      }
    }

    this.#logger.success(`Loaded ${count} event(s).`, 'EventLoader');
    return count;
  }
}
