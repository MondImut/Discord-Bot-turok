/**
 * PluginLoader — Automatically discovers and loads plugins from the plugins/ directory.
 * Plugins are loaded in alphabetical order by directory name.
 * If plugins/ is empty, the bot continues normally without error.
 */

import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

export class PluginLoader {
  #logger;
  #pluginsDir;
  #loadedPlugins = [];

  constructor(logger) {
    this.#logger = logger;
    this.#pluginsDir = path.resolve(process.cwd(), 'plugins');
  }

  /**
   * Scan plugins/ and load every valid plugin.
   * @param {import('../application/Application.js').Application} app
   * @returns {number} Number of plugins successfully loaded.
   */
  async loadAll(app) {
    if (!fs.existsSync(this.#pluginsDir)) {
      this.#logger.info('No plugins/ directory found. Skipping plugin loading.', 'PluginLoader');
      return 0;
    }

    const entries = fs
      .readdirSync(this.#pluginsDir, { withFileTypes: true })
      .filter((e) => e.isDirectory())
      .map((e) => e.name)
      .sort();

    if (entries.length === 0) {
      this.#logger.info('plugins/ directory is empty. No plugins to load.', 'PluginLoader');
      return 0;
    }

    let successCount = 0;

    for (const dirName of entries) {
      await this.#loadPlugin(dirName, app)
        .then(() => successCount++)
        .catch((err) => {
          this.#logger.error(`Plugin "${dirName}" failed to load: ${err.message}`, 'PluginLoader');
        });
    }

    this.#logger.success(`Loaded ${successCount}/${entries.length} plugin(s).`, 'PluginLoader');
    return successCount;
  }

  async #loadPlugin(dirName, app) {
    const indexPath = path.join(this.#pluginsDir, dirName, 'index.js');

    if (!fs.existsSync(indexPath)) {
      this.#logger.warn(`Plugin "${dirName}" has no index.js. Skipping.`, 'PluginLoader');
      return;
    }

    const fileUrl = pathToFileURL(indexPath).href;
    const module = await import(fileUrl);
    const PluginClass = module.default;

    if (!PluginClass || typeof PluginClass !== 'function') {
      throw new Error('Plugin must export a default class.');
    }

    const plugin = new PluginClass();

    if (typeof plugin.onLoad !== 'function') {
      throw new Error('Plugin class must extend PluginBase and implement onLoad().');
    }

    await plugin.onLoad(app);
    this.#loadedPlugins.push(plugin);

    const meta = PluginClass.meta ?? {};
    this.#logger.info(
      `Plugin loaded: ${meta.name ?? dirName} v${meta.version ?? '?'}${meta.description ? ' — ' + meta.description : ''}`,
      'PluginLoader'
    );
  }

  /**
   * Unload all active plugins (calls onUnload on each).
   */
  async unloadAll() {
    for (const plugin of [...this.#loadedPlugins].reverse()) {
      try {
        await plugin.onUnload();
        this.#logger.debug(`Unloaded plugin: ${plugin.name}`, 'PluginLoader');
      } catch (err) {
        this.#logger.error(`Error unloading plugin "${plugin.name}": ${err.message}`, 'PluginLoader');
      }
    }
    this.#loadedPlugins = [];
  }

  get pluginCount() {
    return this.#loadedPlugins.length;
  }
}
