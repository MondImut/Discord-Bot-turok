/**
 * ClientManager — Wraps the discord.js Client with lifecycle management.
 */

import { Client, GatewayIntentBits, Partials, Collection } from 'discord.js';

// Default intents suitable for a general-purpose bot
const DEFAULT_INTENTS = [
  GatewayIntentBits.Guilds,
  GatewayIntentBits.GuildMembers,
  GatewayIntentBits.GuildMessages,
  GatewayIntentBits.GuildMessageReactions,
  GatewayIntentBits.DirectMessages,
  GatewayIntentBits.MessageContent,
];

const DEFAULT_PARTIALS = [
  Partials.Message,
  Partials.Channel,
  Partials.Reaction,
  Partials.User,
  Partials.GuildMember,
];

export class ClientManager {
  #client;
  #logger;
  #token;

  /** Expose the raw discord.js Client for direct access when needed. */
  get client() { return this.#client; }

  constructor(logger, options = {}) {
    this.#logger = logger;

    this.#client = new Client({
      intents: options.intents ?? DEFAULT_INTENTS,
      partials: options.partials ?? DEFAULT_PARTIALS,
      allowedMentions: { parse: ['users', 'roles'], repliedUser: false },
      ...options.clientOptions,
    });

    // Shared storage collections for commands and cooldowns
    this.#client.commands = new Collection();
    this.#client.cooldowns = new Collection();
  }

  /**
   * Log in to Discord.
   * @param {string} token
   */
  async login(token) {
    this.#token = token;
    await this.#client.login(token);
  }

  /**
   * Gracefully destroy the Discord connection.
   */
  async destroy() {
    if (this.#client) {
      this.#client.destroy();
      this.#logger.info('Discord client destroyed.', 'Client');
    }
  }

  /**
   * Register an event listener on the underlying discord.js client.
   */
  on(event, listener) {
    this.#client.on(event, listener);
  }

  once(event, listener) {
    this.#client.once(event, listener);
  }

  get isReady() {
    return this.#client.isReady();
  }

  get user() {
    return this.#client.user;
  }

  get guilds() {
    return this.#client.guilds;
  }
}
