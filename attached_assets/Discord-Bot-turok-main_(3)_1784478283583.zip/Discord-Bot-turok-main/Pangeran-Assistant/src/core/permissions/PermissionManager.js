/**
 * PermissionManager — Discord permission checks and role-based access helpers.
 */

import { PermissionsBitField } from 'discord.js';

export class PermissionManager {
  #logger;

  constructor(logger) {
    this.#logger = logger;
  }

  /**
   * Check whether a guild member has all specified permissions.
   * @param {GuildMember} member
   * @param {PermissionsResolvable[]} permissions
   */
  memberHas(member, permissions) {
    return member.permissions.has(permissions);
  }

  /**
   * Check whether a bot has the required permissions in a given channel.
   * @param {GuildChannel} channel
   * @param {PermissionsResolvable[]} permissions
   */
  botHas(channel, permissions) {
    const botMember = channel.guild?.members.me;
    if (!botMember) return false;
    return channel.permissionsFor(botMember)?.has(permissions) ?? false;
  }

  /**
   * Resolve human-readable names from a permission bit set.
   * @param {bigint|number} bits
   * @returns {string[]}
   */
  resolve(bits) {
    return new PermissionsBitField(bits).toArray();
  }

  /**
   * Assert that a member has all required permissions.
   * Throws a descriptive error if not.
   * @param {GuildMember} member
   * @param {PermissionsResolvable[]} permissions
   */
  assert(member, permissions) {
    if (!this.memberHas(member, permissions)) {
      const needed = new PermissionsBitField(permissions).toArray().join(', ');
      throw new Error(`Missing permissions: ${needed}`);
    }
  }

  /**
   * Check if a user is a guild administrator.
   */
  isAdmin(member) {
    return member.permissions.has(PermissionsBitField.Flags.Administrator);
  }

  /**
   * Check if the interaction user owns the guild.
   */
  isOwner(interaction) {
    return interaction.guild?.ownerId === interaction.user.id;
  }
}
