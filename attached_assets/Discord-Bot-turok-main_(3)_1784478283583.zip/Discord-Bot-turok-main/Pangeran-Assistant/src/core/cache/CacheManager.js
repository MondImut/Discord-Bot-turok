/**
 * CacheManager — In-memory key/value cache with optional TTL expiration.
 */

export class CacheManager {
  #store = new Map();
  #defaultTTL; // seconds; 0 = no expiration

  constructor(defaultTTL = 300) {
    this.#defaultTTL = defaultTTL;
  }

  /**
   * Store a value under the given key.
   * @param {string} key
   * @param {*} value
   * @param {number} [ttl] - override default TTL in seconds (0 = no expiration)
   */
  set(key, value, ttl = this.#defaultTTL) {
    const expiresAt = ttl > 0 ? Date.now() + ttl * 1000 : null;
    this.#store.set(key, { value, expiresAt });
  }

  /**
   * Retrieve a value by key. Returns undefined if missing or expired.
   */
  get(key) {
    const entry = this.#store.get(key);
    if (!entry) return undefined;

    if (entry.expiresAt !== null && Date.now() > entry.expiresAt) {
      this.#store.delete(key);
      return undefined;
    }

    return entry.value;
  }

  /** Check whether a key exists and has not expired. */
  has(key) {
    return this.get(key) !== undefined;
  }

  /** Delete a key from the cache. */
  delete(key) {
    return this.#store.delete(key);
  }

  /** Remove all expired entries. */
  prune() {
    const now = Date.now();
    for (const [key, entry] of this.#store.entries()) {
      if (entry.expiresAt !== null && now > entry.expiresAt) {
        this.#store.delete(key);
      }
    }
  }

  /** Clear the entire cache. */
  clear() {
    this.#store.clear();
  }

  /** Return the number of entries (including potentially expired ones). */
  get size() {
    return this.#store.size;
  }
}
