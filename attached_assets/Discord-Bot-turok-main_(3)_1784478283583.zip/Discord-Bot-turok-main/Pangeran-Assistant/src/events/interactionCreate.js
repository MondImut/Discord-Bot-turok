/**
 * Event: interactionCreate
 * Central handler for all Discord interactions (slash commands, buttons, modals, etc.).
 */

import { InteractionType, MessageFlags } from 'discord.js';

export default {
  name: 'interactionCreate',
  once: false,

  async execute(interaction) {
    // ── Slash Commands ──────────────────────────────────────────────────────
    if (interaction.isChatInputCommand()) {
      const command = interaction.client.commands?.get(interaction.commandName);

      if (!command) {
        await interaction.reply({
          content: `Unknown command: \`/${interaction.commandName}\``,
          flags: MessageFlags.Ephemeral,
        });
        return;
      }

      // Cooldown check
      const cooldowns = interaction.client.cooldowns;
      if (cooldowns) {
        const key = `${interaction.user.id}:${command.data?.name}`;
        const cooldownAmount = (command.cooldown ?? 3) * 1000;
        const now = Date.now();
        const expiration = cooldowns.get(key);

        if (expiration && now < expiration) {
          const remaining = ((expiration - now) / 1000).toFixed(1);
          await interaction.reply({
            content: `⏳ Please wait **${remaining}s** before using \`/${command.data?.name}\` again.`,
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        cooldowns.set(key, now + cooldownAmount);
        setTimeout(() => cooldowns.delete(key), cooldownAmount);
      }

      try {
        await command.execute(interaction);
      } catch (err) {
        console.error(`[interactionCreate] Error in /${interaction.commandName}:`, err);
        const reply = { content: '❌ An error occurred while executing this command.', flags: MessageFlags.Ephemeral };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(reply).catch(() => null);
        } else {
          await interaction.reply(reply).catch(() => null);
        }
      }

      return;
    }

    // ── Autocomplete ────────────────────────────────────────────────────────
    if (interaction.isAutocomplete()) {
      const command = interaction.client.commands?.get(interaction.commandName);
      if (command?.autocomplete) {
        try { await command.autocomplete(interaction); } catch { /* silently ignore */ }
      }
      return;
    }

    // ── Component interactions (buttons, select menus, modals) are handled  ──
    // by individual plugins that register their custom IDs.
  },
};
