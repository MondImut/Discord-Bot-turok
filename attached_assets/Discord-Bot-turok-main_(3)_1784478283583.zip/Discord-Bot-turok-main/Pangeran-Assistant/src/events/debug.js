/**
 * Event: debug
 * Fired when discord.js emits internal debug information.
 * Only active when DEBUG_DISCORD=true in .env.
 */

export default {
  name: 'debug',
  once: false,

  execute(info) {
    if (process.env.DEBUG_DISCORD !== 'true') return;
    console.debug('\x1b[36m🔍 DEBUG\x1b[0m   [Discord Client]', info);
  },
};
