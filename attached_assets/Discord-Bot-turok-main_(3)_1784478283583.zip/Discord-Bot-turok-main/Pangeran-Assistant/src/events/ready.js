/**
 * Event: ready
 * Fired once when the Discord client has logged in and is ready.
 */

export default {
  name: 'ready',
  once: true,

  execute(client) {
    console.log(
      `\x1b[32m✅ SUCCESS\x1b[0m  Logged in as \x1b[1m${client.user.tag}\x1b[0m ` +
      `(${client.guilds.cache.size} guild${client.guilds.cache.size !== 1 ? 's' : ''})`
    );
  },
};
