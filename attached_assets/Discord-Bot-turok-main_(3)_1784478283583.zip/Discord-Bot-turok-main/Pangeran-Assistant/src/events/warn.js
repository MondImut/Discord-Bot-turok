/**
 * Event: warn
 * Fired when discord.js emits a warning message.
 */

export default {
  name: 'warn',
  once: false,

  execute(info) {
    console.warn('\x1b[33m⚠️  WARN\x1b[0m   [Discord Client]', info);
  },
};
