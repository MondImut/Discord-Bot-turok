/**
 * Event: error
 * Fired when the Discord client encounters an error.
 */

export default {
  name: 'error',
  once: false,

  execute(error) {
    console.error('\x1b[31m❌ ERROR\x1b[0m  [Discord Client]', error.message);
  },
};
