/**
 * src/index.js — Pangeran Assistant entry point.
 *
 * Bootstraps the Application and starts the bot.
 */

import { Application } from './core/application/Application.js';

const app = new Application();

app.start().catch((err) => {
  console.error('\x1b[31m❌ FATAL\x1b[0m  Failed to start Pangeran Assistant:', err.message);
  process.exit(1);
});
