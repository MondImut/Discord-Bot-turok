# Pangeran Assistant

Professional Discord Bot Core Framework built with **discord.js v14**, **Node.js LTS**, and **JavaScript ES Modules**.

This is a clean, modular **base framework** — not a feature-complete bot. The architecture is designed so you can add any feature through the plugin system without touching Core code.

---

## Quick Start

```bash
# 1. Enter the project directory
cd Pangeran-Assistant

# 2. Install dependencies
npm install

# 3. Copy the example env file
cp .env.example .env

# 4. Fill in your bot token and client ID in .env
#    DISCORD_TOKEN=your_token_here
#    DISCORD_CLIENT_ID=your_client_id_here

# 5. Start the bot
npm start

# Or in watch mode (auto-restart on file changes)
npm run dev
```

---

## Project Structure

```
Pangeran-Assistant/
├── src/
│   ├── core/
│   │   ├── application/     # Application — root orchestrator
│   │   ├── client/          # ClientManager — discord.js wrapper
│   │   ├── loader/          # EventLoader & PluginLoader
│   │   ├── plugin/          # PluginBase — abstract base for plugins
│   │   ├── database/        # DatabaseManager + adapters/
│   │   ├── config/          # ConfigManager — dotenv + validation
│   │   ├── logger/          # Logger — multi-level, console + file
│   │   ├── scheduler/       # Scheduler — cron-based tasks
│   │   ├── cache/           # CacheManager — in-memory TTL cache
│   │   └── permissions/     # PermissionManager — Discord RBAC
│   │
│   ├── events/              # Core event handlers (ready, interactionCreate, …)
│   ├── shared/
│   │   ├── helpers/         # Utility functions (formatDuration, detectEnvironment, …)
│   │   ├── constants/       # Colors, MS durations, Discord limits
│   │   ├── validators/      # Input validation helpers
│   │   ├── embeds/          # EmbedBuilder factories (successEmbed, errorEmbed, …)
│   │   └── components/      # UI component builders (buttons, select menus)
│   │
│   └── index.js             # Entry point
│
├── plugins/                 # Drop plugin folders here — auto-loaded at startup
├── config/                  # Additional config files (optional)
├── data/
│   ├── database/            # SQLite database files
│   ├── cache/               # Persistent cache (optional)
│   ├── temp/                # Temporary files
│   └── backups/             # Database backups
├── logs/                    # Daily log files (YYYY-MM-DD.log)
├── scripts/                 # Utility scripts
├── tests/                   # Test files
├── docs/                    # Documentation
├── .env.example             # Environment variable template
└── package.json
```

---

## Writing a Plugin

Create a folder inside `plugins/` with an `index.js` file that exports a class extending `PluginBase`:

```js
// plugins/my-plugin/index.js
import { PluginBase } from '../../src/core/plugin/PluginBase.js';

export default class MyPlugin extends PluginBase {
  static meta = {
    name: 'my-plugin',
    version: '1.0.0',
    description: 'My first plugin.',
  };

  async onLoad(app) {
    // app.logger, app.client, app.database, app.cache,
    // app.scheduler, app.permissions, app.config are all available here.
    app.logger.info('MyPlugin is ready!', 'MyPlugin');

    // Register a slash command
    app.client.client.commands.set('ping', {
      data: { name: 'ping', description: 'Replies with Pong!' },
      async execute(interaction) {
        await interaction.reply('🏓 Pong!');
      },
    });
  }

  async onUnload() {
    // Clean up resources on shutdown or hot-reload.
  }
}
```

That's it — the framework discovers it automatically on next startup.

---

## Core Services (available inside plugins via `app`)

| Property | Description |
|---|---|
| `app.logger` | Multi-level logger (debug / info / success / warn / error) |
| `app.config` | Config accessor — `app.config.get('discord.token')` |
| `app.client` | Discord ClientManager — `app.client.client` for the raw Client |
| `app.database` | DatabaseManager — run / get / all / transaction |
| `app.cache` | In-memory TTL cache — set / get / has / delete |
| `app.scheduler` | Cron scheduler — register / unregister / stopAll |
| `app.permissions` | Discord permission helpers — memberHas / botHas / assert |

---

## Environment Variables

| Key | Required | Default | Description |
|---|---|---|---|
| `DISCORD_TOKEN` | ✔ | — | Bot token from Discord Developer Portal |
| `DISCORD_CLIENT_ID` | ✔ | — | Application ID |
| `DISCORD_GUILD_ID` | — | — | Dev guild for guild-scoped commands |
| `BOT_NAME` | — | Pangeran Assistant | Display name |
| `BOT_VERSION` | — | 1.0.0 | Shown in startup banner |
| `DB_ADAPTER` | — | sqlite | Database adapter (sqlite or custom) |
| `DB_PATH` | — | ./data/database/pangeran.db | SQLite file path |
| `LOG_LEVEL` | — | INFO | DEBUG / INFO / SUCCESS / WARN / ERROR |
| `LOG_TO_FILE` | — | true | Write logs to logs/ folder |
| `CACHE_TTL` | — | 300 | Default cache TTL in seconds |
| `DEBUG_DISCORD` | — | false | Enable verbose discord.js debug events |

---

## Hosting Compatibility

Pangeran Assistant auto-detects its hosting environment and displays it in the startup banner:

| Platform | Detection |
|---|---|
| Replit | `REPL_ID` / `REPL_SLUG` env var |
| Railway | `RAILWAY_ENVIRONMENT` env var |
| Pterodactyl | `P_SERVER_UUID` env var |
| Render | `RENDER` env var |
| Heroku | `HEROKU_APP_ID` env var |
| VPS Linux | Fallback on Linux |
| Windows | Fallback on Win32 |

No hardcoded paths — `process.cwd()` is used throughout.

---

## License

MIT — see [LICENSE](./LICENSE).
