---
name: BoomBox Plugin Architecture
description: Key decisions and gotchas for the BoomBox plugin (Pangeran Assistant).
---

## File structure (19 files)
plugins/boombox/
  index.js               ← entry; extends PluginBase; wires all services
  constants.js           ← all CID, SORT_OPTIONS, PERFORMANCE_MODES, PLATFORM_META
  database/BoomBoxDB.js  ← node:sqlite DatabaseSync; WAL mode; all DB methods
  platforms/{YouTube,TikTok,Spotify,index}.js
  core/{QueueManager,WorkerPool,Downloader,SmartCache,HealthMonitor}.js
  ui/{Embeds,Components}.js
  handlers/{MessageHandler,PanelManager,ArchiveHandler,InteractionHandler}.js
  commands/SetupCommand.js

## Critical decisions

**node:sqlite**: Uses Node.js built-in DatabaseSync (no better-sqlite3). Positional args: stmt.run(a,b,c). Never pass an array directly.

**WorkerPool**: Pull-based — workers loop on queue until empty, then exit. Dispatch tries to spawn if slot free. Per-job timeout + retry with backoff.

**SmartCache**: In-memory Map keyed `${guildId}:${platform}:${videoId}`. Preloaded from DB on startup. YouTube URLs expire (~6h), tracked via url_expires_at.

**State encoding in customIDs**: `bb:list:{action}:{p}:{s}:{pg}:{f}` where p=y/t/s/a, s=sort-idx, pg=page, f=0/1/2. Max ~30 chars.

**Panel management**: Monitor panel (stats, workers, queue) + Archive panel (counts, buttons). Both in #boombox-logs. If message deleted → recreate + update DB with new message ID. SetPanelIds via db.upsertConfig(guildId, { monitorMsgId, archiveMsgId }).

**Command registration**: Slash command registered via REST API per guild in `ready` event. Also registered for new guilds via `guildCreate`. Client.commands.set('setupboombox', ...) for core interactionCreate routing.

**app.client** is ClientManager with `.on()`, `.once()` delegates. **app.client.client** is raw discord.js Client. Commands Collection is on `app.client.client.commands`.

**Search state**: Stored server-side in ArchiveHandler.#searchMap (Map<userId, query>), not in customId. Modal customId encodes state: `bb:modal:search:{p}:{s}:{pg}:{f}`.

**Sort**: Cycle approach — Sort button increments sort index mod 6, reloads list in-place via interaction.update().

**Why getAllGuildIds() was added late**: Not in original BoomBoxDB spec; needed by index.js onReady to init panels for all configured guilds.
