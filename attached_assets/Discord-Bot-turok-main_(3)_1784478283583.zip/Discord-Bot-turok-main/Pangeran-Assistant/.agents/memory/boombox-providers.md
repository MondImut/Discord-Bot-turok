---
name: BoomBox multi-provider architecture
description: Provider chain, platform structure, Mp4 direct-link platform, ytdlp async fix.
---

## Platform providers

| Platform | Providers (in order) | File |
|---|---|---|
| YouTube | yt-dlp → yt-dlp+cookies → kaizen → y2mp3 → cobalt | platforms/YouTube.js |
| TikTok | ssstik → tikwm | platforms/TikTok.js |
| Spotify | oembed | platforms/Spotify.js |
| mp4 | (direct download — no provider chain) | platforms/Mp4.js |

## Safe-access pattern
`getYouTubeProviderStatus()` / `getTikTokProviderStatus()` / `getSpotifyProviderStatus()` return `[]` if the registry hasn't been initialized yet — safe to call at any time.

## yt-dlp is ASYNC (critical)
`ytdlp.js` uses async `spawn`, NOT `spawnSync`. Using `spawnSync` blocked the entire Node.js event loop for 13 seconds, freezing all workers and Discord events. Never revert to spawnSync.

**Why:** Node.js is single-threaded. `spawnSync` halts the event loop. Every other conversion, Discord message, and panel update waits until the sync process finishes.

**How to apply:** If yt-dlp needs to be modified, always use `child_process.spawn` with a Promise wrapper and a `setTimeout` kill for the 13s timeout.

## ytdlpCookiesProvider skip
If no cookies file is found in any of the candidate paths, `ytdlpCookiesProvider` throws immediately, letting ProviderRegistry fall through to kaizen. This is intentional — do not remove it.

## Mp4 platform
Added `platforms/Mp4.js` — detects any URL whose pathname ends in `.mp4` (Discord CDN, GitHub Raw, MediaFire, Top4Top, etc.) and passes it directly to Downloader as `audioUrl`. No provider registry needed. `extractMp4Id(url)` hashes the URL (strips query string first) for stable cache dedup.

**Why:** Users often send short video clips as attachments or direct CDN links. These don't go through YouTube/TikTok/Spotify providers — Downloader handles the download → ffmpeg → Top4Top pipeline directly.

**How to apply:** `isMp4Url(url)` + `extractMp4Id(url)` exported from `platforms/index.js`. MessageHandler checks for `message.attachments` MP4 first, then direct URL.
