/**
 * BoomBox Plugin — Entry point.
 * Extends PluginBase; wires all services and registers Discord event listeners.
 *
 * Shutdown order (onUnload):
 *   1. Signal WorkerPool to stop accepting new jobs.
 *   2. Wait up to 15 s for in-progress jobs to finish (graceful drain).
 *   3. Close SQLite database (safe WAL checkpoint).
 *
 * v1.5 changes:
 * - NEW: SetupManager — handles /setupboombox, /delsetupboombox, and the
 *   BoomBox Manager panel (monitoring + setup sub-pages).
 * - NEW: UrlLogsHandler — handles URL Logs panel interactions and pagination.
 * - InteractionHandler now receives SetupManager and UrlLogsHandler.
 * - MessageHandler now receives SetupManager for manager panel auto-update.
 * - Commands /setupboombox and /delsetupboombox re-registered via CommandRegistry.
 */

import { PluginBase }         from '../../src/core/plugin/PluginBase.js';
import { BoomBoxDB }          from './database/BoomBoxDB.js';
import { SmartCache }         from './core/SmartCache.js';
import { QueueManager }       from './core/QueueManager.js';
import { WorkerPool }         from './core/WorkerPool.js';
import { Downloader }         from './core/Downloader.js';
import { HealthMonitor }      from './core/HealthMonitor.js';
import { PanelManager }       from './handlers/PanelManager.js';
import { MessageHandler }     from './handlers/MessageHandler.js';
import { ArchiveHandler }     from './handlers/ArchiveHandler.js';
import { SettingsHandler }    from './handlers/SettingsHandler.js';
import { InteractionHandler } from './handlers/InteractionHandler.js';
import { ErrorLogger }        from './handlers/ErrorLogger.js';
import { ConversionLogger }   from './handlers/ConversionLogger.js';
import { SetupManager }       from './handlers/SetupManager.js';
import { UrlLogsHandler }     from './handlers/UrlLogsHandler.js';
import { PERFORMANCE_MODES }  from './constants.js';

export default class BoomBoxPlugin extends PluginBase {
  static meta = {
    name:        'boombox',
    version:     '1.5.0',
    description: 'BoomBox — YouTube, TikTok & Spotify link converter with BoomBox Manager, URL Logs, multi-provider fallback, smart cache, and error logs.',
  };

  #db;
  #cache;
  #queue;
  #workerPool;
  #downloader;
  #panelManager;
  #messageHandler;
  #archiveHandler;
  #settingsHandler;
  #interactionHandler;
  #errorLogger;
  #conversionLogger;
  #healthMonitor;
  #setupManager;
  #urlLogsHandler;
  #app;

  // ─── Lifecycle ────────────────────────────────────────────────────────────

  async onLoad(app) {
    this.#app = app;
    const log = app.logger;
    log.info('Initializing BoomBox v1.5.0...', 'BoomBox');

    // 1. Database
    this.#db = new BoomBoxDB(log);
    this.#db.open();

    // 2. In-memory smart cache (max 2000 entries total)
    this.#cache = new SmartCache();

    // 3. FIFO job queue
    this.#queue = new QueueManager();

    // 4. Platform converter — cache-first, in-flight dedup, multi-provider fallback
    this.#downloader = new Downloader(this.#db, this.#cache, log);

    // 5. Concurrent worker pool (balanced defaults; overridden per guild on ready)
    const defPm = PERFORMANCE_MODES.balanced;
    this.#workerPool = new WorkerPool(this.#queue, this.#downloader, log, {
      workers: defPm.workers,
      timeout: defPm.timeout,
      retries: defPm.retries,
    });

    // 6. Permanent panels manager (existing 4-panel system)
    this.#panelManager = new PanelManager(this.#db, log);
    this.#panelManager.setPool(this.#workerPool);
    this.#panelManager.setDownloader(this.#downloader);

    // 7. Feature handlers
    this.#archiveHandler  = new ArchiveHandler(this.#db, log);
    this.#settingsHandler = new SettingsHandler(this.#db, this.#cache, this.#workerPool, this.#panelManager, log);

    // 8. NEW: BoomBox Manager (setup system + monitoring panel)
    this.#setupManager = new SetupManager(this.#db, this.#cache, this.#workerPool, this.#panelManager, log);

    // 9. NEW: URL Logs Handler
    this.#urlLogsHandler = new UrlLogsHandler(this.#db, log);
    this.#setupManager.setUrlLogsHandler(this.#urlLogsHandler);

    // 10. Error + Conversion loggers
    this.#errorLogger      = new ErrorLogger(app.client.client, this.#db, log);
    this.#conversionLogger = new ConversionLogger(app.client.client, this.#db, log);

    // 11. MessageHandler (receives setupManager for manager panel auto-update)
    this.#messageHandler = new MessageHandler(
      this.#db, this.#workerPool, log,
      this.#errorLogger, this.#conversionLogger,
      this.#panelManager, this.#setupManager,
    );

    // 12. InteractionHandler (receives setupManager + urlLogsHandler)
    this.#interactionHandler = new InteractionHandler(
      this.#archiveHandler,
      this.#settingsHandler,
      this.#db,
      log,
      this.#setupManager,
      this.#urlLogsHandler,
    );

    // 13. Health monitor (panel refresh every 5 min, per-guild isolated)
    this.#healthMonitor = new HealthMonitor(this.#workerPool, this.#panelManager, this.#db, log);
    this.#healthMonitor.schedule(app.scheduler);

    // 14. Register slash commands
    const client = app.client;
    client.client.commands.set('setupboombox', {
      data: {
        name:        'setupboombox',
        description: 'Setup BoomBox Manager — Buat panel monitoring dan konfigurasi BoomBox.',
      },
      execute: (interaction) => this.#setupManager.handleSetupCommand(interaction),
    });

    client.client.commands.set('delsetupboombox', {
      data: {
        name:        'delsetupboombox',
        description: 'Hapus konfigurasi BoomBox (panel + pengaturan). Arsip URL tetap disimpan.',
      },
      execute: (interaction) => this.#setupManager.handleDeleteCommand(interaction),
    });

    // 15. Discord event listeners
    // Slash commands are dispatched by the core interactionCreate event handler.
    // Plugins only need to listen for component interactions (buttons, selects, modals).
    client.on('messageCreate',     (msg) => this.#messageHandler.handle(msg));
    client.on('interactionCreate', (i)   => this.#interactionHandler.handle(i));

    // 16. Post-ready: restore panels + preload cache
    client.once('ready', (discordClient) => this.#onReady(app, discordClient));

    log.success('BoomBox v1.5.0 initialized. Waiting for Discord ready...', 'BoomBox');
  }

  async #onReady(app, discordClient) {
    const log = app.logger;

    // Record bot start time so the monitor panel can display accurate uptime.
    this.#panelManager.setUptimeStart(Date.now());

    // Give HealthMonitor the Discord client so it can recover deleted panels.
    this.#healthMonitor.setClient(discordClient);

    const configuredIds = this.#db.getAllGuildIds();
    await Promise.allSettled(
      configuredIds.map(async (guildId) => {
        const guild  = discordClient.guilds.cache.get(guildId);
        const config = this.#db.getConfig(guildId);
        if (!guild || !config) return;

        // Apply saved performance mode
        const pm = PERFORMANCE_MODES[config.perf_mode] ?? PERFORMANCE_MODES.balanced;
        this.#workerPool.updateConfig({ workers: pm.workers, timeout: pm.timeout, retries: pm.retries });

        // Preload SmartCache (capped at 500 most-recently-used entries)
        const loaded = this.#cache.preload(this.#db, guildId);
        log.debug(`Cache preloaded: ${loaded} entries for guild ${guildId}`, 'BoomBox');

        // Restore existing 4-panel system (for guilds that had old setup)
        await this.#panelManager.initGuild(guild, config, this.#db).catch((err) =>
          log.warn(`Panel init failed for ${guildId}: ${err.message}`, 'BoomBox'),
        );

        // Restore BoomBox Manager panel + URL Logs panel (new system)
        if (config.ch_monitor) {
          await this.#setupManager.initGuild(guild, config).catch((err) =>
            log.warn(`Manager panel init failed for ${guildId}: ${err.message}`, 'BoomBox'),
          );
        }
      }),
    );

    log.success('BoomBox v1.5.0 is fully operational! 🎵', 'BoomBox');
  }

  // ─── Graceful Shutdown ────────────────────────────────────────────────────

  async onUnload() {
    const log = this.#app?.logger;
    log?.info('BoomBox shutting down...', 'BoomBox');

    if (this.#workerPool) {
      await this.#workerPool.drain(15_000);
    }

    this.#db?.close();
    log?.info('BoomBox unloaded cleanly.', 'BoomBox');
  }
}
