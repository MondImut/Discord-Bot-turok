/**
 * BoomBox v1.5 Feature Test Suite
 * Run: node plugins/boombox/test/feature-test.mjs
 *
 * Tests all major systems WITHOUT requiring a live Discord connection.
 * Uses an in-memory / temp-file DB so the real data is untouched.
 */

import { randomUUID } from 'crypto';
import { tmpdir }     from 'os';
import { join }       from 'path';
import { unlinkSync, existsSync } from 'fs';

// ─── Minimal logger stub ──────────────────────────────────────────────────────
const log = {
  info:    (m) => console.log(`  ℹ  ${m}`),
  success: (m) => console.log(`  ✅ ${m}`),
  warn:    (m) => console.log(`  ⚠  ${m}`),
  error:   (m) => console.log(`  ❌ ${m}`),
  debug:   ()  => {},
};

// ─── Test harness ─────────────────────────────────────────────────────────────
let passed = 0, failed = 0;
const results = [];
function test(name, fn) {
  results.push({ name, fn });
}
async function run() {
  for (const { name, fn } of results) {
    try {
      await fn();
      console.log(`  ✅ PASS  ${name}`);
      passed++;
    } catch (e) {
      console.log(`  ❌ FAIL  ${name}\n         → ${e.message}`);
      failed++;
    }
  }
  console.log(`\n${'─'.repeat(60)}`);
  console.log(`  TOTAL: ${passed + failed}  PASS: ${passed}  FAIL: ${failed}`);
  if (failed > 0) process.exitCode = 1;
}
function assert(cond, msg = 'Assertion failed') {
  if (!cond) throw new Error(msg);
}
function assertEqual(a, b, msg) {
  if (a !== b) throw new Error(msg ?? `Expected ${JSON.stringify(b)}, got ${JSON.stringify(a)}`);
}

// ─── Import modules ───────────────────────────────────────────────────────────
import { BoomBoxDB }   from '../database/BoomBoxDB.js';
import { SmartCache }  from '../core/SmartCache.js';
import {
  processingEmbed, successEmbed, errorEmbed,
  managerEmbed, managerSetupPageEmbed, managerWorkerPageEmbed,
  urlLogsPanelEmbed, archivePanelEmbed, settingsEmbed,
  recentLogsEmbed, listEmbed, previewEmbed, statsEmbed,
} from '../ui/Embeds.js';
import {
  managerMainRows, managerPlatformPageRows, managerChannelPageRows,
  managerWorkerPageRows, urlLogsPanelRows, archivePanelRows, settingsRows,
  successActionRow, encodeState, decodeState,
} from '../ui/Components.js';
import { COLORS, MCID, CID, PLATFORM_META, PERFORMANCE_MODES } from '../constants.js';

const DB_PATH = join(tmpdir(), `boombox_test_${randomUUID()}.db`);
process.env.BOOMBOX_DB_PATH = DB_PATH;

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 1: Database
// ─────────────────────────────────────────────────────────────────────────────
console.log('\n━━━ 1. DATABASE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

let db;
test('DB opens without error', () => {
  db = new BoomBoxDB(log);
  db.open(DB_PATH);
});

test('upsertConfig creates a row', () => {
  db.upsertConfig('guild1', { chMonitor: 'ch_monitor_1' });
  const c = db.getConfig('guild1');
  assert(c, 'Config row not found');
  assertEqual(c.guild_id, 'guild1');
});

test('getConfig returns null for unknown guild', () => {
  const c = db.getConfig('nonexistent_guild');
  assertEqual(c, null);
});

test('updatePlatformSettings persists yt fields', () => {
  db.updatePlatformSettings('guild1', 'yt', {
    enabled: 1, gifProcessing: 'https://example.com/proc.gif',
    gifSuccess: 'https://example.com/succ.gif', maxDuration: 300,
  });
  const c = db.getConfig('guild1');
  assertEqual(c.yt_enabled, 1, 'yt_enabled');
  assertEqual(c.yt_max_duration, 300, 'yt_max_duration');
  assert(c.yt_gif_processing?.includes('proc.gif'), 'yt_gif_processing URL');
});

test('updateWorkerSettings persists worker fields', () => {
  db.updateWorkerSettings('guild1', { queueLimit: 75, cacheLimit: 1500, autoRestart: true });
  const c = db.getConfig('guild1');
  assertEqual(c.queue_limit, 75);
  assertEqual(c.cache_limit, 1500);
});

test('setUrlLogsChannel + setUrlLogsMsgId', () => {
  db.setUrlLogsChannel('guild1', 'ch_url_logs_1');
  db.setUrlLogsMsgId('guild1', 'msg_urllogs_1');
  const c = db.getConfig('guild1');
  assertEqual(c.ch_url_logs, 'ch_url_logs_1');
  assertEqual(c.url_logs_msg_id, 'msg_urllogs_1');
});

test('setManagerMsgId', () => {
  db.setManagerMsgId('guild1', 'msg_manager_1');
  const c = db.getConfig('guild1');
  assertEqual(c.manager_msg_id, 'msg_manager_1');
});

test('upsertMedia stores and retrieves', () => {
  const m = db.upsertMedia('guild1', {
    platform: 'youtube', videoId: 'abc123', title: 'Test Video',
    duration: 240, boomboxUrl: 'https://top4top.io/test.mp3', urlExpiresAt: null,
  });
  assert(m?.id, 'No media id returned');
  const found = db.findMedia('guild1', 'youtube', 'abc123');
  assert(found, 'Media not found after upsert');
  assertEqual(found.title, 'Test Video');
});

test('upsertMedia deduplicates (same videoId) — updates URL not title', () => {
  const newUrl = 'https://top4top.io/test2.mp3';
  db.upsertMedia('guild1', {
    platform: 'youtube', videoId: 'abc123', title: 'Ignored Title',
    duration: 240, boomboxUrl: newUrl, urlExpiresAt: null,
  });
  const all = db.listMedia('guild1', { platform: 'youtube', limit: 100, offset: 0 });
  const matches = all.rows.filter(r => r.video_id === 'abc123');
  assertEqual(matches.length, 1, 'Duplicate entry created');
  // upsertMedia updates boombox_url on conflict, not title
  assertEqual(matches[0].boombox_url, newUrl, 'boombox_url not updated on re-upsert');
});

test('upsertMedia stores TikTok entry', () => {
  db.upsertMedia('guild1', {
    platform: 'tiktok', videoId: 'tk_999', title: 'TikTok Dance',
    duration: 45, boomboxUrl: 'https://top4top.io/tk.mp3', urlExpiresAt: null,
  });
  const found = db.findMedia('guild1', 'tiktok', 'tk_999');
  assert(found, 'TikTok media not found');
});

test('listMedia paginates correctly', () => {
  // Add more entries
  for (let i = 0; i < 8; i++) {
    db.upsertMedia('guild1', {
      platform: 'youtube', videoId: `vid_${i}`, title: `Video ${i}`,
      duration: 120 + i, boomboxUrl: `https://top4top.io/${i}.mp3`, urlExpiresAt: null,
    });
  }
  const page1 = db.listMedia('guild1', { platform: 'youtube', limit: 5, offset: 0 });
  assert(page1.rows.length <= 5, 'Page 1 has too many rows');
  assert(page1.total >= 9, 'Total count wrong'); // abc123 + 8 new
});

test('recordConversionFull increments daily stats', () => {
  db.recordConversionFull('guild1', { platform: 'youtube', cacheHit: false, success: true, elapsedMs: 1200 });
  db.recordConversionFull('guild1', { platform: 'youtube', cacheHit: true,  success: true, elapsedMs: 50  });
  db.recordConversionFull('guild1', { platform: 'tiktok',  cacheHit: false, success: false, elapsedMs: 500 });
  const s = db.getStats('guild1');
  assert(s, 'No stats row');
  assert(s.daily_requests >= 3, `daily_requests=${s.daily_requests}`);
  assert(s.daily_success  >= 2, `daily_success=${s.daily_success}`);
  assert(s.daily_failed   >= 1, `daily_failed=${s.daily_failed}`);
});

test('getAllGuildIds returns configured guilds', () => {
  db.upsertConfig('guild2', { chMonitor: 'ch_mon_2' });
  const ids = db.getAllGuildIds();
  assert(ids.includes('guild1'), 'guild1 missing');
  assert(ids.includes('guild2'), 'guild2 missing');
});

test('deleteGuildConfig removes config row, keeps media', () => {
  db.upsertMedia('guild2', {
    platform: 'spotify', videoId: 'sp_1', title: 'Spotify Track',
    duration: 200, boomboxUrl: 'https://top4top.io/sp.mp3', urlExpiresAt: null,
  });
  db.deleteGuildConfig('guild2');
  const c = db.getConfig('guild2');
  assertEqual(c, null, 'Config not deleted');
  // Media should still be accessible
  const m = db.findMedia('guild2', 'spotify', 'sp_1');
  assert(m, 'Media was incorrectly deleted with config');
});

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 2: SmartCache
// ─────────────────────────────────────────────────────────────────────────────
console.log('\n━━━ 2. SMART CACHE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

let cache;
test('SmartCache instantiates', () => {
  cache = new SmartCache();
  assert(cache, 'Cache not created');
});

test('set + get returns stored URL', () => {
  cache.set('g1', 'youtube', 'vid1', 'https://top4top.io/1.mp3', null);
  const url = cache.get('g1', 'youtube', 'vid1');
  assertEqual(url, 'https://top4top.io/1.mp3');
});

test('get returns null for unknown key', () => {
  const url = cache.get('g1', 'youtube', 'nonexistent');
  assertEqual(url, null);
});

test('invalidate removes a key', () => {
  cache.set('g1', 'youtube', 'vid2', 'https://top4top.io/2.mp3', null);
  cache.invalidate('g1', 'youtube', 'vid2');
  const url = cache.get('g1', 'youtube', 'vid2');
  assertEqual(url, null);
});

test('cache size stays at or below max (2000)', () => {
  const c2 = new SmartCache(100); // small cap for test
  for (let i = 0; i < 150; i++) {
    c2.set('g1', 'youtube', `vid${i}`, `url${i}`, null);
  }
  assert(c2.size <= 100, `Cache size ${c2.size} exceeds max 100`);
});

test('preload fills cache from DB', () => {
  const c3 = new SmartCache(500);
  const loaded = c3.preload(db, 'guild1');
  assert(typeof loaded === 'number', 'preload did not return count');
  assert(loaded >= 0, 'preload count is negative');
});

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 3: Embeds
// ─────────────────────────────────────────────────────────────────────────────
console.log('\n━━━ 3. EMBEDS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

const fakeUser = { id: 'u1', username: 'TestUser', tag: 'TestUser#0001' };
const fakeConfig = {
  yt_enabled: 1, yt_gif_processing: 'https://img.example.com/proc.gif',
  yt_gif_success: null, yt_max_duration: 300,
  ch_youtube: 'ch1', ch_tiktok: 'ch2', ch_spotify: null,
  ch_errors: null, ch_url_logs: null,
  worker_count: 3, perf_mode: 'balanced', delete_msgs: 0, reply_mode: 'reply',
};
const fakeMedia = {
  id: 1, platform: 'youtube', video_id: 'abc123',
  title: 'Test Video', duration: 240,
  boombox_url: 'https://top4top.io/test.mp3',
  created_at: Math.floor(Date.now() / 1000),
  last_used: Math.floor(Date.now() / 1000),
  total_used: 5,
};

test('processingEmbed (no config/user) — returns embed with title', () => {
  const e = processingEmbed('youtube');
  assert(e.data?.title?.includes('Mohon'), `Bad title: ${e.data?.title}`);
});

test('processingEmbed (with config) — embed has image field for GIF', () => {
  const e = processingEmbed('youtube', fakeConfig, fakeUser);
  assert(e.data?.image?.url?.includes('proc.gif'), 'GIF not set as image');
  assert(e.data?.footer?.text?.includes('TestUser'), 'User not in footer');
});

test('processingEmbed (TikTok, no gif) — no image field', () => {
  const e = processingEmbed('tiktok', fakeConfig, fakeUser);
  assert(!e.data?.image, 'Unexpected image on TikTok with no gif configured');
});

test('successEmbed — has BoomBox URL field and thumbnail for YouTube', () => {
  const e = successEmbed(fakeMedia, false, 1200, fakeConfig, fakeUser);
  const fields = e.data?.fields ?? [];
  const urlField = fields.find(f => f.name === 'BoomBox URL');
  assert(urlField, 'BoomBox URL field missing');
  assert(e.data?.thumbnail?.url?.includes('abc123'), 'YouTube thumbnail missing');
  assert(e.data?.footer?.text?.includes('TestUser'), 'User not in footer');
});

test('successEmbed (cache hit) — has ⚡ in footer', () => {
  const e = successEmbed(fakeMedia, true, 50, fakeConfig, fakeUser);
  assert(e.data?.footer?.text?.includes('Cache'), 'Cache hit not reflected');
});

test('errorEmbed — shows platform, no stack trace', () => {
  const e = errorEmbed('youtube', fakeUser);
  const data = JSON.stringify(e.data);
  assert(!data.includes('stack'), 'Stack trace leaked into public embed');
  assert(e.data?.color, 'No color on error embed');
  assert(e.data?.footer?.text?.includes('TestUser'), 'User not in footer');
});

test('managerEmbed — has all key fields', () => {
  const stats = { total_convert: 10, total_convert_ms: 12000, daily_requests: 5, daily_success: 4, daily_failed: 1 };
  const counts = { total: 30, yt: 20, tk: 8, sp: 2 };
  const ws = { activeWorkers: 2, queueSize: 0, cacheSize: 15 };
  const e = managerEmbed(stats, counts, ws, fakeConfig, Date.now() - 60_000);
  const fields = e.data?.fields ?? [];
  const fnames = fields.map(f => f.name);
  assert(fnames.some(n => n.includes('Worker')),    'Worker field missing');
  assert(fnames.some(n => n.includes('YouTube')),   'YouTube count missing');
  assert(fnames.some(n => n.includes('Total URL')), 'Total URL missing');
  assert(fnames.some(n => n.includes('Convert Time')), 'Convert time missing');
});

test('managerSetupPageEmbed (yt) — has Channel, Status, Max Durasi', () => {
  const e = managerSetupPageEmbed(fakeConfig, 'yt');
  const fnames = (e.data?.fields ?? []).map(f => f.name);
  assert(fnames.includes('Channel'),    'Channel field missing');
  assert(fnames.includes('Status'),     'Status field missing');
  assert(fnames.includes('Max Durasi'), 'Max Durasi field missing');
});

test('managerSetupPageEmbed (error) — references Error Logs in description', () => {
  const e = managerSetupPageEmbed(fakeConfig, 'error');
  assert(e.data?.description?.toLowerCase().includes('error'), 'Error description missing');
});

test('managerSetupPageEmbed (urllogs) — references URL Logs in description', () => {
  const e = managerSetupPageEmbed(fakeConfig, 'urllogs');
  assert(e.data?.description?.toLowerCase().includes('url'), 'URL Logs description missing');
});

test('managerWorkerPageEmbed — has Worker Aktif and Mode Auto fields', () => {
  const e = managerWorkerPageEmbed(fakeConfig);
  const fnames = (e.data?.fields ?? []).map(f => f.name);
  assert(fnames.some(n => n.includes('Worker Aktif')), 'Worker Aktif missing');
  assert(fnames.some(n => n.includes('Auto')), 'Auto mode field missing');
});

test('urlLogsPanelEmbed — is a valid embed with title', () => {
  const e = urlLogsPanelEmbed();
  assert(e.data?.title?.includes('URL'), `Bad title: ${e.data?.title}`);
  assert(e.data?.description?.length > 10, 'Empty description');
});

test('recentLogsEmbed (empty) — shows fallback message', () => {
  const e = recentLogsEmbed([]);
  assert(e.data?.description?.includes('Belum'), 'Empty state message missing');
});

test('recentLogsEmbed (with entries) — shows entry count lines', () => {
  const entries = [
    { platform: 'youtube', title: 'Song A', created_at: Date.now() / 1000 },
    { platform: 'tiktok',  title: 'Dance B', created_at: Date.now() / 1000 },
  ];
  const e = recentLogsEmbed(entries);
  assert(e.data?.description?.includes('Song A'),  'Entry 1 missing');
  assert(e.data?.description?.includes('Dance B'), 'Entry 2 missing');
});

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 4: Components
// ─────────────────────────────────────────────────────────────────────────────
console.log('\n━━━ 4. COMPONENTS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

test('managerMainRows — returns 2 rows (buttons + select)', () => {
  const rows = managerMainRows();
  assertEqual(rows.length, 2, `Expected 2 rows, got ${rows.length}`);
  const btnRow = rows[0];
  assert(btnRow.components?.length === 4, `Expected 4 buttons, got ${btnRow.components?.length}`);
  const selectRow = rows[1];
  assertEqual(selectRow.components?.length, 1, 'Expected 1 select menu');
});

test('managerMainRows — all manager button CIDs are correct', () => {
  const rows = managerMainRows();
  const cids = rows[0].components.map(c => c.data?.custom_id);
  assert(cids.includes(MCID.REFRESH),     `REFRESH CID missing — got [${cids}]`);
  assert(cids.includes(MCID.WORKER_PAGE), `WORKER_PAGE CID missing`);
  assert(cids.includes(MCID.CLEAR_CACHE), `CLEAR_CACHE CID missing`);
  assert(cids.includes(MCID.SAVE),        `SAVE CID missing`);
});

test('managerMainRows — select menu has 5 options', () => {
  const rows = managerMainRows();
  const select = rows[1].components[0];
  // discord.js StringSelectMenuBuilder stores options in .options, not .data.options
  const optCount = select.options?.length ?? select.data?.options?.length;
  assertEqual(optCount, 5, `Expected 5 options, got ${optCount}`);
});

test('managerPlatformPageRows (yt) — returns 2 rows', () => {
  const rows = managerPlatformPageRows(fakeConfig, 'yt');
  assertEqual(rows.length, 2);
});

test('managerPlatformPageRows (tk) — channel select CID is CH_TK', () => {
  const rows = managerPlatformPageRows(fakeConfig, 'tk');
  const chSelect = rows[0].components[0];
  assertEqual(chSelect.data?.custom_id, MCID.CH_TK);
});

test('managerPlatformPageRows — back button present', () => {
  const rows = managerPlatformPageRows(fakeConfig, 'yt');
  const btns = rows[1].components.map(c => c.data?.custom_id);
  assert(btns.includes(MCID.BACK), 'Back button missing');
});

test('managerChannelPageRows (error) — channel select CID is CH_ERRORS', () => {
  const rows = managerChannelPageRows('error');
  assertEqual(rows[0].components[0].data?.custom_id, MCID.CH_ERRORS);
  const btnCids = rows[1].components.map(c => c.data?.custom_id);
  assert(btnCids.includes('bb:mgr:error:save'), 'Error save button CID wrong');
  assert(btnCids.includes(MCID.BACK), 'Back button missing');
});

test('managerChannelPageRows (urllogs) — channel select CID is CH_URLLOGS', () => {
  const rows = managerChannelPageRows('urllogs');
  assertEqual(rows[0].components[0].data?.custom_id, MCID.CH_URLLOGS);
  const btnCids = rows[1].components.map(c => c.data?.custom_id);
  assert(btnCids.includes('bb:mgr:urllogs:save'), 'URL Logs save button CID wrong');
});

test('managerWorkerPageRows — +1/-1 buttons disabled at boundaries', () => {
  const rowsMin = managerWorkerPageRows(1, fakeConfig);
  const rowsMax = managerWorkerPageRows(10, fakeConfig);
  const minBtns = rowsMin[0].components;
  const maxBtns = rowsMax[0].components;
  assert(minBtns[0].data?.disabled === true,  'Minus not disabled at 1');
  assert(maxBtns[1].data?.disabled === true,   'Plus not disabled at 10');
  assert(minBtns[1].data?.disabled !== true,   'Plus disabled at 1 (wrong)');
  assert(maxBtns[0].data?.disabled !== true,   'Minus disabled at 10 (wrong)');
});

test('urlLogsPanelRows — 3 platform buttons', () => {
  const rows = urlLogsPanelRows();
  assertEqual(rows.length, 1, 'Expected 1 row');
  const cids = rows[0].components.map(c => c.data?.custom_id);
  assert(cids.includes(MCID.URLLOGS_YT), `YT CID missing — ${cids}`);
  assert(cids.includes(MCID.URLLOGS_TK), `TK CID missing`);
  assert(cids.includes(MCID.URLLOGS_SP), `SP CID missing`);
});

test('successActionRow — copy + preview buttons', () => {
  const rows = successActionRow(42);
  assertEqual(rows.length, 1);
  const cids = rows[0].components.map(c => c.data?.custom_id);
  assert(cids.some(id => id.includes('copy')),    'Copy button missing');
  assert(cids.some(id => id.includes('preview')), 'Preview button missing');
  assert(cids.every(id => id.includes('42')),     'Media ID not embedded in CID');
});

test('encodeState + decodeState roundtrip', () => {
  const enc = encodeState('y', 2, 5, 1);
  const dec = decodeState(enc);
  assertEqual(dec.p, 'y');
  assertEqual(dec.s, 2);
  assertEqual(dec.pg, 5);
  assertEqual(dec.f, 1);
});

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 5: Constants / CID integrity
// ─────────────────────────────────────────────────────────────────────────────
console.log('\n━━━ 5. CONSTANTS & CID INTEGRITY ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

test('MCID has all required manager keys', () => {
  const required = [
    'REFRESH','WORKER_PAGE','CLEAR_CACHE','SAVE','BACK','DROPDOWN',
    'SETUP_SAVE','SETUP_CH',
    'CH_YT','CH_TK','CH_SP','CH_ERRORS','CH_URLLOGS',
    'YT_TOGGLE','TK_TOGGLE','SP_TOGGLE',
    'YT_MEDIA','TK_MEDIA','SP_MEDIA',
    'WORKER_MINUS','WORKER_PLUS','WORKER_AUTO','WORKER_LIMITS',
    'MODAL_YT_MEDIA','MODAL_TK_MEDIA','MODAL_SP_MEDIA','MODAL_WORKER_LIMITS',
    'URLLOGS_YT','URLLOGS_TK','URLLOGS_SP','URLLOGS_NAV',
    'DEL_CONFIRM','DEL_CANCEL',
  ];
  const missing = required.filter(k => !MCID[k]);
  assert(missing.length === 0, `Missing MCID keys: ${missing.join(', ')}`);
});

test('All MCID values start with bb:', () => {
  const bad = Object.entries(MCID).filter(([, v]) => !v.startsWith('bb:'));
  assert(bad.length === 0, `Bad CID values: ${bad.map(([k]) => k).join(', ')}`);
});

test('No duplicate MCID values', () => {
  const vals = Object.values(MCID);
  const dupes = vals.filter((v, i) => vals.indexOf(v) !== i);
  assert(dupes.length === 0, `Duplicate MCID values: ${dupes.join(', ')}`);
});

test('PLATFORM_META has youtube, tiktok, spotify', () => {
  assert(PLATFORM_META.youtube, 'youtube missing');
  assert(PLATFORM_META.tiktok,  'tiktok missing');
  assert(PLATFORM_META.spotify, 'spotify missing');
  assert(PLATFORM_META.youtube.color, 'youtube has no color');
});

test('PERFORMANCE_MODES has eco, balanced, performance, custom keys', () => {
  assert(PERFORMANCE_MODES.eco,         'eco missing');
  assert(PERFORMANCE_MODES.balanced,    'balanced missing');
  assert(PERFORMANCE_MODES.performance, 'performance missing');
  assert(PERFORMANCE_MODES.custom,      'custom missing');
  assert(PERFORMANCE_MODES.balanced.workers >= 1, 'balanced.workers invalid');
});

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 6: URL Logs pagination logic
// ─────────────────────────────────────────────────────────────────────────────
console.log('\n━━━ 6. URL LOGS PAGINATION ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
import { UrlLogsHandler } from '../handlers/UrlLogsHandler.js';

test('UrlLogsHandler instantiates', () => {
  const h = new UrlLogsHandler(db, log);
  assert(h, 'Handler not created');
});

test('listMedia page size respected (PAGE_SIZE = 5)', async () => {
  const p1 = db.listMedia('guild1', { platform: 'youtube', limit: 5, offset: 0 });
  const p2 = db.listMedia('guild1', { platform: 'youtube', limit: 5, offset: 5 });
  assert(p1.rows.length <= 5, `Page 1 too large: ${p1.rows.length}`);
  assert(p1.total > 0, 'Total is 0');
  if (p1.total > 5) {
    assert(p2.rows.length > 0, 'Page 2 empty when total > 5');
  }
});

test('listMedia — empty result for unused platform in guild', () => {
  const r = db.listMedia('guild1', { platform: 'spotify', limit: 5, offset: 0 });
  assertEqual(r.total, 0, `Expected 0, got ${r.total}`);
});

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 7: MessageHandler — max-duration gate (unit-level)
// ─────────────────────────────────────────────────────────────────────────────
console.log('\n━━━ 7. MAX-DURATION GATE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

test('Max-duration error has correct shape', () => {
  const durErr = new Error('Duration exceeded');
  durErr.isMaxDurationError = true;
  durErr.duration    = 400;
  durErr.maxDuration = 300;
  assert(durErr.isMaxDurationError, 'Flag not set');
  assertEqual(durErr.duration,    400, 'duration');
  assertEqual(durErr.maxDuration, 300, 'maxDuration');
});

test('Duration 300 with max=300 should NOT trigger (edge case = ok)', () => {
  // Simulate the check: maxDur > 0 && resolved.duration > maxDur
  const maxDur = 300, duration = 300;
  const wouldBlock = maxDur > 0 && duration > maxDur;
  assertEqual(wouldBlock, false, 'Exact-equal duration incorrectly blocked');
});

test('Duration 301 with max=300 SHOULD trigger', () => {
  const maxDur = 300, duration = 301;
  const wouldBlock = maxDur > 0 && duration > maxDur;
  assertEqual(wouldBlock, true, 'Over-limit not blocked');
});

test('maxDur=0 disables the gate', () => {
  const maxDur = 0, duration = 99999;
  const wouldBlock = maxDur > 0 && duration > maxDur;
  assertEqual(wouldBlock, false, 'Gate fired when maxDur=0');
});

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 8: Manager panel state machine (via constants check)
// ─────────────────────────────────────────────────────────────────────────────
console.log('\n━━━ 8. STATE MACHINE STATES ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

test('All expected state values exist as strings in MCID keys', () => {
  // worker_setup is accessed via the dedicated Worker button, NOT the dropdown.
  // The dropdown only contains platform + channel setup options.
  const states = ['yt_setup','tk_setup','sp_setup','error_setup','urllogs_setup'];
  // Dropdown options are in .options (not .data.options) on discord.js builders
  const rows = managerMainRows();
  const select = rows[1].components[0];
  const opts = select.options ?? select.data?.options ?? [];
  const optionValues = opts.map(o => o.value ?? o.data?.value);
  for (const state of states) {
    assert(optionValues.includes(state), `State "${state}" not in dropdown options — found: [${optionValues}]`);
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// RUN ALL TESTS
// ─────────────────────────────────────────────────────────────────────────────
console.log('');
await run();

// Cleanup
try { db?.close(); } catch (_) {}
try { if (existsSync(DB_PATH)) unlinkSync(DB_PATH); } catch (_) {}
