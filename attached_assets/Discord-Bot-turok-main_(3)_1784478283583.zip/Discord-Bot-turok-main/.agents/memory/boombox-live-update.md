---
name: BoomBox Live Update Architecture
description: How all 5 panels update in-place after each conversion; no new messages ever sent to ch_logs.
---

## Rule
All BoomBox panel updates use `message.edit()` — no `channel.send()` after initial setup.

## 5 Permanent Panels
| Panel | Channel | msg_id DB column |
|-------|---------|-----------------|
| Monitor | ch_monitor | monitor_msg_id |
| Archive | ch_logs | archive_msg_id |
| Settings | ch_settings | settings_msg_id |
| Manager | ch_logs | manager_msg_id |
| **Logs** (NEW) | ch_logs | logs_msg_id |

## After Each Conversion (MessageHandler.onSuccess)
Three panels are updated in parallel (fire-and-forget, never blocks user reply):
1. `panelManager.updateLogsPanel(guildId)` — shows last 5 conversions via `recentLogsEmbed()`
2. `panelManager.updateArchivePanel(guildId)` — updates total/per-platform counts
3. `panelManager.updateMonitorPanel(guildId)` — updates stats/worker status

## HealthMonitor Tick (every 5 min)
Also calls updateLogsPanel + updateArchivePanel + updateMonitorPanel per guild, as a fallback.

## ConversionLogger
Still instantiated in index.js for backward compat but no longer sends new messages to ch_logs.
The live logs panel (panel #5) replaces its function.

**Why:** User requirement: "JANGAN membuat message baru jika data berubah. Gunakan message.edit()."

## DB
`logs_msg_id` column added via safeAlter (v1.4). `getRecentMedia(guildId, limit=5)` added to BoomBoxDB.
`upsertConfig` supports `logsMsgId` field.
