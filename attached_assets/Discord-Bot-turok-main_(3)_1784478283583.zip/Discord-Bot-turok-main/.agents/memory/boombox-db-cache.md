---
name: BoomBox DB and cache notes
description: Key facts about BoomBoxDB, SmartCache, and schema decisions.
---

## SQLite driver

Uses `better-sqlite3` (synchronous), NOT Node.js built-in `node:sqlite` (requires Node 22.5+).
This was the first crash blocker when the project was imported.

## SmartCache (v1.2)

- Max 2000 entries across all guilds. New entries evict oldest when at capacity.
- Preload capped at 500 most-recently-used entries per guild (was 9999 — memory risk).
  - Call: `cache.preload(db, guildId)` — sorts by `last_used DESC`, limit 500.
- `cache.clearGuild(guildId)` — deletes all keys starting with `${guildId}:`.

## BoomBoxDB schema

- `boombox_config` — guild config, panel message IDs, perf mode, channel IDs
- `boombox_media` — media archive (persistent across config resets)
- `boombox_favorites` — per-user favorites (references media by ID with ON DELETE CASCADE)
- `boombox_stats` — conversion counters per guild

## deleteGuildConfig

`db.deleteGuildConfig(guildId)` → deletes from `boombox_config` only.
Media archive, favorites, and stats are preserved. This allows re-setup to show existing data.

## upsertConfig partial update

`upsertConfig(guildId, data)` only updates fields where `data[key] !== undefined`.
To clear panel message IDs: `{ monitorMsgId: null, archiveMsgId: null, settingsMsgId: null }`.
