---
name: BoomBox setup overhaul
description: How /setupboombox and /delsetupboombox work after the v1.2 rewrite.
---

## /setupboombox flow

**Not configured:**
1. `/setupboombox` → show manual modal directly (4 channel ID inputs)
2. Modal submit → validate channels → store in `#pendingSetups` (15 min TTL) → show perf select
3. Perf select → save config to DB → init panels async

**Already configured:**
1. `/setupboombox` → show rebuild menu embed + 4 buttons
2. Update Setup → show manual modal again (fresh setup)
3. Rebuild Panel → delete old panel messages → re-create via `panelManager.rebuildPanels()`
4. Remove Setup → `#doRemoveSetup()`: clear panels + SmartCache + deleteGuildConfig()
5. Cancel → dismiss

## /delsetupboombox

Same as Remove Setup. Calls `#doRemoveSetup(guildId, guild)`.
- Deletes panel messages from Discord (gracefully, ignores errors)
- Clears SmartCache for guild (`cache.clearGuild(guildId)`)
- Deletes config row from DB (`db.deleteGuildConfig(guildId)`)
- Does NOT delete Discord channels
- Does NOT delete media archive (boombox_media/boombox_stats/boombox_favorites)

## Memory leak fix

`#pendingSetups` now has a 15-min TTL per entry (stored as `expiresAt`).
`#evictStalePending()` is called at the start of `handlePerfSelect()`.

## Auto setup removed

`handleAutoSetup` and the SETUP_AUTO button are gone. The Auto Setup option that used to create Discord channels automatically has been removed. Only manual channel selection is supported.

## SetupCommand constructor

v1.2 constructor: `(db, panelManager, workerPool, cache, logger)` — cache added as 4th arg for `clearGuild` in `#doRemoveSetup`.
