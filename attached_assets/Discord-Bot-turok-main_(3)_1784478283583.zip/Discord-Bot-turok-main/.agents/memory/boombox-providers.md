---
name: BoomBox multi-provider architecture
description: How the ProviderRegistry works, provider order, and the download→ffmpeg→Top4Top pipeline.
---

## Architecture

`platforms/ProviderRegistry.js` — generic health-tracking multi-provider class.
- Providers tried in registration order; skips disabled ones.
- Disable threshold: ≥60% fail rate in last 10 attempts → 5 min cooldown.
- Auto-re-enable after cooldown (checked at start of each `resolve()` call).
- `getStatus()` is always safe (no async, no logging).

## Platform registries (module-level singletons)

Each platform file has:
- `getXxxRegistry(logger)` — creates registry on first call with the provided logger.
- `getXxxProviderStatus()` — safe getter: returns `_registry?.getStatus() ?? []`.
  - Handles case where registry was not yet initialized (before any conversion).

## YouTube providers (order matters — v1.4+)
1. `yt-dlp`  — binary at ~/.pythonlibs/bin/yt-dlp; downloads to local file; returns `filePath`
2. `kaizen`  — kaizenapi.my.id, no key; returns `audioUrl`
3. `y2mp3`   — hub.y2mp3.co (ytmp3.gg backend), no key; returns `audioUrl`
4. `cobalt`  — cobalt.tools public API; skips if JWT required; returns `audioUrl`

ytdl-core removed — frequently blocked by YouTube bot-check.

## TikTok providers
1. `tikwm`  — tikwm.com (existing, reliable); returns `audioUrl`
2. `ssstik` — ssstik.io scrape (fallback); returns `audioUrl`

## Spotify providers
1. `oembed` — oEmbed + page scrape for 30-sec preview URL; returns `audioUrl`

## Provider return format (v1.4+)
Providers no longer return `boomboxUrl`. They return ONE of:
- `filePath` — file already on disk (yt-dlp). Downloader skips HTTP download.
- `audioUrl` — CDN URL to download. Downloader fetches it to temp file.

Downloader.js then handles: (fetch if needed) → ffmpeg 64kbps MP3 → Top4Top upload → cleanup → boomboxUrl = Top4Top URL.

## Download → Upload pipeline (Downloader.js)
1. Provider chain → `{ audioUrl } | { filePath }`
2. If `audioUrl`: fetch to `/tmp/boombox_raw_<uid>.<ext>`
3. ffmpeg → `/tmp/boombox_<uid>.mp3` at 64 kbps, metadata stripped
4. Upload to top4top.io → permanent URL
5. TempCleaner.flush() deletes both temp files
6. Persist Top4Top URL as `boomboxUrl` in DB + SmartCache (no TTL — permanent)

## New utility files
- `utils/ffmpeg.js` — `convertToMp3(input, output, {bitrate, timeout})`; finds ffmpeg at Replit nix path
- `utils/TempCleaner.js` — `track(path) / flush()` / static `deleteAll(paths)`
- `upload/top4top.js` — `uploadToTop4Top(filePath)` → `{ url, deleteUrl }` via native fetch+FormData

## yt-dlp binary path
`/home/runner/workspace/.pythonlibs/bin/yt-dlp` (installed via `pip install yt-dlp --user --break-system-packages`)

## Important: logger initialization race
`getAllProviderStatus()` is called by `PanelManager.updateMonitorPanel()` which fires even before any conversion. DO NOT use `getYouTubeRegistry()` in `getAllProviderStatus()` — it would create the registry without a logger. Always use `getYouTubeProviderStatus()` (safe optional chaining).

**Why:** If the registry is created without a logger in `getAllProviderStatus()`, subsequent `resolve()` calls will crash when the logger is `undefined`.

## Files
- `platforms/ProviderRegistry.js`
- `platforms/YouTube.js`, `TikTok.js`, `Spotify.js`
- `platforms/providers/youtube/{ytdlp,cobalt,y2mp3,kaizen}.js`
- `platforms/providers/tiktok/{tikwm,ssstik}.js`
- `platforms/providers/spotify/oembed.js`
- `platforms/index.js` — `resolveUrl(url, platform, logger)` and `getAllProviderStatus()`
- `core/Downloader.js` — full download→encode→upload pipeline
- `utils/ffmpeg.js`, `utils/TempCleaner.js`, `upload/top4top.js`
