---
name: QueueManager.isEmpty getter bug
description: isEmpty is a getter not a method; calling it as isEmpty() throws.
---

## The bug

`QueueManager.isEmpty` is a getter:
```js
get isEmpty() { return this.#jobs.length === 0; }
```

`WorkerPool.js` was calling it as `this.#queue.isEmpty()` (with parentheses).
This throws: `this[#queue].isEmpty is not a function`.

## Fix applied

Changed both occurrences in `WorkerPool.js`:
- `while (!this.#queue.isEmpty())` → `while (!this.#queue.isEmpty)`
- `if (!this.#stopping && !this.#queue.isEmpty())` → `if (!this.#stopping && !this.#queue.isEmpty)`

**Why:** JavaScript getters can't be called with `()`. The getter itself works fine; the caller was wrong.
