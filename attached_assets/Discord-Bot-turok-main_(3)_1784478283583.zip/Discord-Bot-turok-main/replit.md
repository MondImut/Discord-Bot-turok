# Pangeran Assistant

Professional Discord Bot built with **discord.js v14**, **Node.js LTS**, and **JavaScript ES Modules**.

## Quick Start

```bash
cd Pangeran-Assistant
npm install
cp .env.example .env
# Fill DISCORD_TOKEN and DISCORD_CLIENT_ID in .env
npm start
```

## Required Environment Variables

| Variable | Required | Description |
|---|---|---|
| `DISCORD_TOKEN` | ✔ | Bot token from Discord Developer Portal |
| `DISCORD_CLIENT_ID` | ✔ | Application ID from Discord Developer Portal |
| `DISCORD_GUILD_ID` | — | Guild ID for dev (guild-scoped commands; faster updates) |
| `BOT_NAME` | — | Display name (default: Pangeran Assistant) |
| `BOT_VERSION` | — | Version string |
| `LOG_LEVEL` | — | DEBUG / INFO / SUCCESS / WARN / ERROR |
| `LOG_TO_FILE` | — | Write logs to `logs/` folder |

## Project Structure

```
Pangeran-Assistant/
├── src/                   # Core framework
│   ├── core/              # Application, ClientManager, Registry, DB, etc.
│   ├── events/            # Core Discord event handlers
│   └── shared/            # Helpers, constants, validators, embeds
└── plugins/
    └── boombox/           # BoomBox plugin (YouTube/TikTok/Spotify converter)
        ├── constants.js   # CIDs, colors, platform meta
        ├── core/          # WorkerPool, QueueManager, Downloader, SmartCache, HealthMonitor
        ├── database/      # BoomBoxDB (better-sqlite3)
        ├── handlers/
        │   ├── SetupManager.js       # /setupboombox, /delsetupboombox, Manager panel
        │   ├── UrlLogsHandler.js     # URL Logs panel + pagination
        │   ├── PanelManager.js       # 4-panel system (Monitor, Archive, Settings, Logs)
        │   ├── InteractionHandler.js # Routes all bb: interactions
        │   ├── MessageHandler.js     # Listens for links in platform channels
        │   ├── ArchiveHandler.js     # Browse/search/paginate URL archive
        │   ├── SettingsHandler.js    # Old settings panel
        │   ├── ErrorLogger.js        # Posts rich errors to ch_errors
        │   └── ConversionLogger.js   # Legacy compat
        ├── platforms/     # YouTube, TikTok, Spotify providers
        ├── ui/
        │   ├── Embeds.js      # All EmbedBuilder factories
        │   └── Components.js  # All ActionRow/Button/Select factories
        ├── upload/        # top4top uploader
        └── utils/         # ffmpeg, TempCleaner
```

## BoomBox Plugin — Setup Flow (v1.5)

### First-time setup
1. Run `/setupboombox` (owner/admin only)
2. Select the **BoomBox Monitoring** channel → Click **Simpan**
3. The **BoomBox Manager** panel appears in that channel

### BoomBox Manager Panel
- **Buttons**: Refresh | Worker | Clear Cache | Save
- **Dropdown — Setup BoomBox**:
  - Setup YouTube → pick channel, toggle enable/disable, set GIF URLs & max duration
  - Setup TikTok → same
  - Setup Spotify → same
  - BoomBox Error → pick Error Logs channel
  - URL Logs → pick URL Logs channel → creates URL Logs panel

### URL Logs Panel
Public panel with YouTube/TikTok/Spotify buttons.
Each button sends an ephemeral paginated list (5 per page) only visible to the user who clicked.

### Delete setup
Run `/delsetupboombox` → confirm → removes panels + config (archive preserved).

## Workflow

Run: `cd Pangeran-Assistant && node src/index.js`

## User Preferences

- Keep existing module/plugin architecture; do not restructure
- Do not touch WorkerPool, QueueManager, Downloader, Provider, SmartCache
- Do not touch the URL archive (boombox_media, boombox_favorites, boombox_stats)
- Use `better-sqlite3` (not `node:sqlite`) for all database work
